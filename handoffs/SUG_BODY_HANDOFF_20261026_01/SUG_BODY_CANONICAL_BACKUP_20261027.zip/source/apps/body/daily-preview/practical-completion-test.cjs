'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const L=require('./iphone-lan-preview.cjs');let tests=0;
function check(name,fn){fn();tests++;console.log('OK '+name)}
check('LAN preview refuses public and wildcard binds',()=>{assert.equal(L.isPrivateHost('0.0.0.0'),false);assert.equal(L.isPrivateHost('8.8.8.8'),false);assert.equal(L.isPrivateHost('192.168.1.20'),true);assert.equal(L.isPrivateHost('172.20.1.2'),true);assert.equal(L.isPrivateHost('127.0.0.1'),true)});
check('LAN preview requires token prefix and refuses traversal',()=>{const t='AbCdEfGhIjKlMnOpQrStUvWx';assert.equal(L.fileForRequest('/wrong/apps/body/daily-preview/index.html',t),null);assert.equal(L.fileForRequest('/'+t+'/../../Windows/win.ini',t),null);assert.match(L.fileForRequest('/'+t+'/apps/body/daily-preview/index.html',t),/daily-preview[\\/]index\.html$/)});
check('LAN preview limits served assets',()=>{const t='AbCdEfGhIjKlMnOpQrStUvWx';assert.equal(L.fileForRequest('/'+t+'/ios/SuGMember/HealthKitManager.swift',t),null);assert.match(L.fileForRequest('/'+t+'/assets/quest/person-gps-core-20260905.js',t),/person-gps-core-20260905\.js$/)});
const nativeRoot=path.resolve(__dirname,'../../../ios/SuGMember');
const health=fs.readFileSync(path.join(nativeRoot,'HealthKitManager.swift'),'utf8'),web=fs.readFileSync(path.join(nativeRoot,'MemberWebView.swift'),'utf8'),content=fs.readFileSync(path.join(nativeRoot,'ContentView.swift'),'utf8');
check('native HealthKit bridge reads resting energy separately',()=>{assert.match(health,/basalEnergyBurned/);assert.match(health,/@Published var restingEnergyKcal/);assert.match(health,/fetchTodayRestingEnergyKcal/)});
check('native payload carries both energy components and progress coverage',()=>{assert.match(web,/restingEnergyKcal/);assert.match(web,/"coverageStart"/);assert.match(web,/"coverageEnd"/);assert.match(web,/"isComplete":false/);assert.match(content,/restingEnergyKcal: health\.restingEnergyKcal/)});
check('dashboard UI labels rule-based and received energy states',()=>{const ui=fs.readFileSync('automation-ui.js','utf8');assert.match(ui,/実AI未接続/);assert.match(ui,/総消費/);assert.match(ui,/e\.label/);assert.match(ui,/目標との差/)});
console.log(JSON.stringify({suite:'practical-completion-static',tests,passed:tests,scope:'static and pure LAN/native bridge checks; no iPhone, Xcode, HealthKit or network'}));

'use strict';

const path = require('path');
const {
  DEFAULT_OUTPUT,
  runCatalogCreation,
  validateApprovedDraft
} = require(path.resolve(__dirname, '../../../api/body-square-sandbox-catalog-create.cjs'));

function parseArgs(argv) {
  let apiVersion = '2026-09-16';
  let validateDraft = false;
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--api-version') {
      apiVersion = argv[index + 1] || '';
      index += 1;
    } else if (argv[index] === '--validate-draft') {
      validateDraft = true;
    } else {
      throw new Error('UNSUPPORTED_ARGUMENT');
    }
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(apiVersion)) throw new Error('SQUARE_API_VERSION_INVALID');
  return { apiVersion, validateDraft };
}

async function readToken(stream = process.stdin) {
  stream.setEncoding('utf8');
  let data = '';
  for await (const chunk of stream) {
    data += chunk;
    if (data.length > 4096) throw new Error('SQUARE_SANDBOX_TOKEN_TOO_LONG');
  }
  return data.replace(/[\r\n]+$/g, '');
}

async function main() {
  const { apiVersion, validateDraft } = parseArgs(process.argv.slice(2));
  if (validateDraft) {
    const validation = validateApprovedDraft();
    if (!validation.ready) throw new Error('FOUR_OBJECT_DRAFT_INVALID');
    process.stdout.write('SQUARE_SANDBOX_FOUR_OBJECT_DRAFT_VALID\n');
    return;
  }
  const accessToken = await readToken();
  const result = await runCatalogCreation({ accessToken, apiVersion });
  process.stdout.write(`${JSON.stringify({
    ok: ['created_verified', 'existing_verified'].includes(result.status),
    status: result.status,
    resultFile: DEFAULT_OUTPUT,
    merchantIdMasked: result.merchant.idMasked,
    itemIdMasked: result.verification?.item?.idMasked || '',
    itemVariationIdMasked: result.verification?.itemVariation?.idMasked || '',
    planIdMasked: result.verification?.plan?.idMasked || '',
    variationIdMasked: result.verification?.variation?.idMasked || '',
    amount: result.verification?.variation?.amount || 0,
    currency: result.verification?.variation?.currency || '',
    cadence: result.verification?.variation?.cadence || '',
    postCount: result.apiOperations.postCount
  }, null, 2)}\n`);
}

if (require.main === module) {
  main().catch((error) => {
    const safe = error?.safeResult;
    process.stderr.write(`${JSON.stringify({
      ok: false,
      status: safe?.status || 'failed',
      errorCode: safe?.errorCode || 'SQUARE_SANDBOX_CATALOG_CREATE_FAILED',
      resultFile: DEFAULT_OUTPUT,
      postCount: safe?.apiOperations?.postCount || 0
    })}\n`);
    process.exitCode = 1;
  });
}

module.exports = { main, parseArgs, readToken };

# BODY 7画面対応表

2026-10-26。画面承認前。今回の変更は候補内のDOM再配置と導線追加。既存の保存関数・入力DOM・イベントリスナーを再利用。

|画面・ハッシュ|既存ファイル（候補内）|入力|出力|保存先|受渡し|未接続・未確認|
|---|---|---|---|---|---|---|
|今日 #today|app.js / today-connect.js / menu-content.js / prescription-ui.js|目標・体重・日別回復・活動・過去実績|当日の提案と理由・記録集約|共通キーの days / profile / workouts / trainingPlans を参照。方針はdays|記録フォームへの下書き、回復・ケア、設定へ|個別提案の実機確認、最新UI確認|
|マップ #map|walk-ui.js / walk-core.js / app.js|手入力歩数・距離／明示開始時GPS|距離推定、保存前確認|days / walkSessions|今日・日別記録へ。取得地点の外部地図は明示操作のみ|実地図埋込み、実GPS・iPhone確認、背景追跡|
|食事 #food|food-review.js / food-connection.js / journal-ui.js|写真選択・料理・量・栄養値、候補の修正|保存前確認、日別合計|foods / foodEdits|カロリー計算は別タブ。結果自動取込なし|Gemini/OpenAI実解析、認証・利用制限、最新UI確認|
|トレーニング #training|training.js / sheet-training.js / plan-save.js / plan-progress.js / training-explain.js / training-reuse.js|種目・条件・日付・重量・回数・セット、TM・刻み、手応え|予定、実績、比較、理由説明|trainingPlans と workouts を分離、workoutEdits|既存プラン作成は別タブ。5/3/1週を未保存の記録欄へ呼出|外部プラン結果の自動取込、最新UI確認|
|回復＋ #recovery（旧#careも同画面へ）|app.js / care-guidance.js / recheck-ui.js|睡眠・疲れ・ストレス・痛み、10部位の観察・仮説・実践・前後変化|回復記録、ケア記録、実施後再確認|days / cares / exerciseRechecks|今日の提案、既存self-coach.htmlへのリンク|医学的診断なし。実機・最新UI確認|
|記録・特典 #record|journal-ui.js / continuation.js / app.js|日付選択、JSON保存・読込、既存記録の明示参照|日別・体重・食事・運動・ケア履歴、特典案内|weights等を含む共通キー、JSONは新しい復元領域のみ|既存BODYの運動記録は読取専用|実ポイント・割引精算、交換条件、最新UI確認|
|プロフィール・連携設定 #settings|app.jsの既存profileForm / health-intake.js|名前・身長・体重・体脂肪・目標、受信項目と集計日|プロフィール、受信候補、取込結果、接続状況|profile / healthReceipts / days / weights|sug_native_health_v1を明示読取。本人領域のみ。会員HUBへ戻る|HealthKit許可状態・最終同期は未取得。距離・体脂肪・活動エネルギー取込は未接続|

## 保存設定
共通キー：sug_body_daily_candidate_20261026_v1。開発テストは末尾 _test。JSON復元はさらに _restore_<32桁ID>。今回の画面整理は保存キー・形式・既存データに変更なし。テスト値を自動投入しない。

## 既存ツールと資料
- プラン作成：https://koji06ochi-ship-it.github.io/-SuG-TRAINING-PLAN-GENERATOR/
- カロリー・PFC：https://s-u-g-body-calculator.vercel.app/
- 月間記録：https://docs.google.com/spreadsheets/d/1lueSaTgKt7vYF1qyjeI6iZIWboZ9RFr0/edit
- 種目・プラン資料：https://docs.google.com/spreadsheets/d/1-pMVrzN951_rR-SFZI9wfiQXyJd1o0k6z6LCQKuo2oo/edit
- 5/3/1：https://docs.google.com/spreadsheets/d/1SawB6k4v_U9PObbZwgz7SwmgMmajeu1bKoxSTOnZu3M/edit
資料はsheet-sources.json、sheet-training.js等の保存済み内容を使用。今回は再取得していない。

## 操作の配置
下部6項目：今日／マップ／食事／トレーニング／回復＋／記録・特典。右上「設定」で7画面目。今日には7画面の一覧入口。回復＋に既存careノードを移し、旧#careも有効。トレーニングでは既存5/3/1パネルを入口のすぐ下へ移動。既存フォームを複製しない。

## 正式素材
asset-manifest.jsonに記録された原本10点はSHA一致。今回も変換・描き直しなし。音姫画像は保管のみで、この追加コードにUI参照なし。

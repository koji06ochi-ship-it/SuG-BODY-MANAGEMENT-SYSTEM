'use strict';

const assert = require('node:assert/strict');
const path = require('node:path');
const api = path.resolve(__dirname, '../../../api');
const core = require(path.join(api, 'body-square-sandbox-subscription-lifecycle.cjs'));
const lifecycle = require(path.join(api, 'body-subscription-entitlement.cjs'));

let passed = 0;
async function check(name, fn) {
  try { await fn(); passed += 1; console.log('PASS', name); }
  catch (error) { console.error('FAIL', name, error); process.exitCode = 1; }
}

(async () => {
  await check('Sandbox base is fixed and Production endpoint is absent', () => {
    assert.equal(core.SANDBOX_BASE, 'https://connect.squareupsandbox.com');
    assert.doesNotMatch(core.SANDBOX_BASE, /^https:\/\/connect\.squareup\.com/);
  });
  await check('test customer and card references are fixed non-personal values', () => {
    assert.equal(core.CUSTOMER_REFERENCE, 'sug-body-sandbox-lifecycle-v1');
    assert.equal(core.CARD_REFERENCE, 'sug-body-sandbox-card-v1');
  });
  await check('API recorder masks object IDs in endpoint labels', async () => {
    const operations = [];
    const requester = core.createRequester({ accessToken: 'mock', apiVersion: '2026-09-16', operations, fetchImpl: async () => ({ ok: true, status: 200, text: async () => '{}' }) });
    await requester.get('/v2/payments/private-id');
    assert.deepEqual(operations[0], { method: 'GET', endpoint: '/v2/payments/{payment_id}', httpStatus: 200 });
    assert.doesNotMatch(JSON.stringify(operations), /private-id/);
  });
  await check('invoice totals require exact JPY 1480 values', () => {
    assert.deepEqual(core.moneyTotals({ payment_requests: [{ computed_amount_money: { amount: 1480, currency: 'JPY' }, total_completed_amount_money: { amount: 1480, currency: 'JPY' } }] }), { computed: 1480, completed: 1480, currencies: ['JPY'] });
  });
  await check('month extension stays a calendar date', () => {
    assert.equal(core.addMonth('2026-10-31'), '2026-11-30');
    assert.equal(core.addMonth('2026-11-30'), '2026-12-30');
  });
  await check('paid_until_date takes priority over charged_through_date', () => {
    const binding = { accountId: 'a', productId: 'body_general', subscriptionId: 's', planVariationId: 'v', customerId: 'c' };
    const event = { event_id: 'e', type: 'invoice.payment_made' };
    const subscription = { id: 's', customer_id: 'c', plan_variation_id: 'v', status: 'ACTIVE', paid_until_date: '2026-11-30', charged_through_date: '2026-12-31' };
    const invoice = { id: 'i', subscription_id: 's', status: 'PAID', payment_requests: [{ computed_amount_money: { amount: 1480, currency: 'JPY' }, total_completed_amount_money: { amount: 1480, currency: 'JPY' } }] };
    assert.equal(lifecycle.planLifecycleMutation({ event, subscription, invoice, binding }).validUntil, '2026-11-30');
  });
  await check('ACTIVE subscription with canceled_date schedules period-end expiry', () => {
    const binding = { accountId: 'a', productId: 'body_general', subscriptionId: 's', planVariationId: 'v', customerId: 'c' };
    const event = { event_id: 'e', type: 'subscription.updated' };
    const subscription = { id: 's', customer_id: 'c', plan_variation_id: 'v', status: 'ACTIVE', paid_until_date: '2026-11-30', canceled_date: '2026-11-30' };
    const mutation = lifecycle.planLifecycleMutation({ event, subscription, binding });
    assert.equal(mutation.action, 'schedule_expiry');
    assert.equal(mutation.validUntil, '2026-11-30');
    assert.equal(mutation.billingStatus, 'cancel_scheduled');
  });
  await check('local lifecycle separates actual canonical data from mock events', async () => {
    const subscription = { id: 's', customer_id: 'c', plan_variation_id: 'v', status: 'ACTIVE', paid_until_date: '2026-11-30' };
    const invoice = { id: 'i', subscription_id: 's', status: 'PAID', payment_requests: [{ computed_amount_money: { amount: 1480, currency: 'JPY' }, total_completed_amount_money: { amount: 1480, currency: 'JPY' } }] };
    const result = await core.applyMockLifecycle({ subscription, invoice, customerId: 'c', planVariationId: 'v' });
    assert.equal(result.storage, 'local_memory_only');
    assert.equal(result.duplicate.secondGrantPrevented, true);
    assert.equal(result.paymentFailure.mode, 'mock');
    assert.equal(result.partialRefund.manualReview, true);
    assert.equal(result.fullRefund.finalEntitlementStatus, 'revoked');
    assert.equal(result.signature.validAccepted, true);
    assert.equal(result.signature.invalidRejected, true);
  });
  await check('memory store rejects another account', async () => {
    const store = core.createMemoryStore({ accountId: 'owner' });
    await assert.rejects(() => store.applyAtomic({ event_id: 'e' }, { accountId: 'other', productId: 'body_general', action: 'revoke' }), /OWNER_OR_PRODUCT/);
  });
  await check('poll stops after the first ready response', async () => {
    let calls = 0;
    const result = await core.poll(async () => ({ ready: ++calls === 2 }), { attempts: 5, delayMs: 0, sleep: async () => {} });
    assert.equal(result.ready, true);
    assert.equal(calls, 2);
  });
  console.log(JSON.stringify({ passed, total: 10, scope: 'Square Sandbox lifecycle safety and local entitlement mocks; no network or DB' }));
})().catch((error) => { console.error(error); process.exitCode = 1; });

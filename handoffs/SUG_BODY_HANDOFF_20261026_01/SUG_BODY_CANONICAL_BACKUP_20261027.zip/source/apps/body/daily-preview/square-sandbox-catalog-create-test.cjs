'use strict';

const assert = require('assert');
const path = require('path');
const { SANDBOX_BASE, runCatalogCreation } = require(path.resolve(__dirname, '../../../api/body-square-sandbox-catalog-create.cjs'));

const TOKEN = 'sandbox-test-token-never-write';
const merchant = { id: 'sandbox-merchant-4DBN', status: 'ACTIVE', country: 'JP', currency: 'JPY' };
const itemVariation = { type: 'ITEM_VARIATION', id: 'ITEM-VARIATION-0004', present_at_all_locations: true, item_variation_data: { item_id: 'ITEM-0001', name: '一般向け月額', pricing_type: 'FIXED_PRICING', price_money: { amount: 1480, currency: 'JPY' } } };
const createdObjects = [
  { type: 'ITEM', id: 'ITEM-0001', present_at_all_locations: true, item_data: { name: 'S.u.G BODY', product_type: 'REGULAR', is_taxable: false, variations: [itemVariation] } },
  { type: 'SUBSCRIPTION_PLAN', id: 'PLAN-0002', present_at_all_locations: true, subscription_plan_data: { name: 'S.u.G BODY 一般向け', eligible_item_ids: ['ITEM-0001'], all_items: false } },
  { type: 'SUBSCRIPTION_PLAN_VARIATION', id: 'VARIATION-0003', present_at_all_locations: true, subscription_plan_variation_data: { name: '月額1,480円（税込）', subscription_plan_id: 'PLAN-0002', can_prorate: false, phases: [{ ordinal: 0, cadence: 'MONTHLY', pricing: { type: 'STATIC', price_money: { amount: 1480, currency: 'JPY' } } }] } }
];

function response(status, body) {
  return { ok: status >= 200 && status < 300, status, text: async () => JSON.stringify(body) };
}

function mockFetch({ before = [], failStage = '', networkFailure = false } = {}) {
  const calls = [];
  const state = before.map((object) => JSON.parse(JSON.stringify(object)));
  const fetchImpl = async (url, options = {}) => {
    calls.push({ url, options });
    assert.ok(url.startsWith(SANDBOX_BASE), 'Sandbox endpoint only');
    assert.ok(!url.includes('connect.squareup.com'), 'Production endpoint blocked');
    assert.strictEqual(options.headers.Authorization, `Bearer ${TOKEN}`);
    if (url.endsWith('/v2/merchants')) return response(200, { merchant: [merchant] });
    if (url.includes('/v2/catalog/list?')) return response(200, { objects: state });
    if (url.endsWith('/v2/catalog/object')) {
      const body = JSON.parse(options.body);
      const type = body.object.type;
      const stage = type === 'ITEM' ? 'item' : type === 'SUBSCRIPTION_PLAN' ? 'plan' : 'variation';
      if (stage === failStage) {
        if (networkFailure) throw new Error('simulated timeout');
        return response(400, { errors: [{ code: 'BAD_REQUEST' }] });
      }
      const index = type === 'ITEM' ? 0 : type === 'SUBSCRIPTION_PLAN' ? 1 : 2;
      const replacement = JSON.parse(JSON.stringify(createdObjects[index]));
      if (type === 'SUBSCRIPTION_PLAN') replacement.subscription_plan_data.eligible_item_ids = body.object.subscription_plan_data.eligible_item_ids;
      if (type === 'SUBSCRIPTION_PLAN_VARIATION') replacement.subscription_plan_variation_data.subscription_plan_id = body.object.subscription_plan_variation_data.subscription_plan_id;
      state.push(replacement);
      return response(200, { catalog_object: replacement });
    }
    throw new Error('unexpected endpoint');
  };
  return { calls, fetchImpl };
}

let assertions = 0;
function check(value, message) {
  assertions += 1;
  assert.ok(value, message);
}

async function testCreateAndVerify() {
  const mock = mockFetch();
  let written;
  const result = await runCatalogCreation({ accessToken: TOKEN, fetchImpl: mock.fetchImpl, idempotencyKey: 'fixed-idempotency-key', checkedAt: '2026-10-26T00:00:00.000Z', writeResult: (value) => { written = JSON.parse(JSON.stringify(value)); } });
  const posts = mock.calls.filter((call) => call.options.method === 'POST');
  check(result.status === 'created_verified', 'created and verified');
  check(posts.length === 3 && result.apiOperations.postCount === 3, 'three ordered POSTs');
  check(posts.every((call) => call.url.endsWith('/v2/catalog/object')), 'official upsert endpoint only');
  const payloads = posts.map((call) => JSON.parse(call.options.body));
  check(payloads.map((body) => body.object.type).join(',') === 'ITEM,SUBSCRIPTION_PLAN,SUBSCRIPTION_PLAN_VARIATION', 'approved object types and order only');
  const nestedItemVariations = payloads[0].object.item_data.variations;
  check(nestedItemVariations.length === 1 && nestedItemVariations[0].type === 'ITEM_VARIATION' && nestedItemVariations[0].item_variation_data.name === '一般向け月額', 'one approved nested item variation');
  check(nestedItemVariations[0].item_variation_data.item_id === payloads[0].object.id, 'item variation links parent item');
  check(nestedItemVariations[0].item_variation_data.pricing_type === 'FIXED_PRICING' && nestedItemVariations[0].item_variation_data.price_money.amount === 1480 && nestedItemVariations[0].item_variation_data.price_money.currency === 'JPY', 'item variation fixed JPY 1480');
  check(payloads[1].object.subscription_plan_data.eligible_item_ids[0] === 'ITEM-0001', 'plan links confirmed item ID');
  check(payloads[2].object.subscription_plan_variation_data.subscription_plan_id === 'PLAN-0002', 'variation links confirmed plan ID');
  const phase = payloads[2].object.subscription_plan_variation_data.phases[0];
  check(phase.cadence === 'MONTHLY' && phase.pricing.price_money.amount === 1480 && phase.pricing.price_money.currency === 'JPY', 'monthly JPY 1480');
  check(phase.periods === undefined && payloads[2].object.subscription_plan_variation_data.can_prorate === false, 'indefinite and no proration');
  check(payloads.every((body) => body.object.present_at_all_locations === true) && nestedItemVariations[0].present_at_all_locations === true, 'objects enabled at all locations');
  check(payloads.every((body) => body.object.type !== 'TAX') && payloads[0].object.item_data.is_taxable === false && !payloads[0].object.item_data.tax_ids, 'no tax object or tax reference');
  check(result.verification.relationships.itemVariationLinkedItem && result.verification.relationships.planEligibleItem && result.verification.relationships.variationLinkedPlan, 'returned relationships verified');
  check(result.verification.tax.finalCatalogPriceJpy === 1480 && result.verification.tax.itemTaxReferenceCount === 0, 'final catalog amount and no added tax reference');
  check(result.verification.variation.periods === null, 'indefinite returned plan');
  check(result.mutations.approvedCatalogItem === 1 && result.mutations.approvedCatalogItemVariation === 1 && result.mutations.approvedSubscriptionPlan === 1 && result.mutations.approvedSubscriptionPlanVariation === 1, 'approved mutations counted');
  check(Object.entries(result.mutations).filter(([key]) => !key.startsWith('approved')).every(([, value]) => value === 0), 'prohibited mutations zero');
  const saved = JSON.stringify(written);
  check(!saved.includes(TOKEN) && !saved.includes('ITEM-0001') && !saved.includes('ITEM-VARIATION-0004') && !saved.includes('PLAN-0002') && !saved.includes('VARIATION-0003'), 'result excludes token and full object IDs');
  check(result.merchant.idMasked === '***4DBN', 'merchant is masked');
  check(result.apiOperations.getCount === 5, 'GET before and after each write');
}

async function testExistingDoesNotPost() {
  const mock = mockFetch({ before: createdObjects });
  const result = await runCatalogCreation({ accessToken: TOKEN, fetchImpl: mock.fetchImpl, writeResult: () => {} });
  check(result.status === 'existing_verified', 'valid existing set reused');
  check(mock.calls.every((call) => call.options.method === 'GET'), 'existing set causes no POST');
}

async function testPartialStops() {
  const mock = mockFetch({ before: [createdObjects[0]] });
  let failure;
  try { await runCatalogCreation({ accessToken: TOKEN, fetchImpl: mock.fetchImpl, writeResult: () => {} }); } catch (error) { failure = error; }
  check(failure?.safeResult?.status === 'rejected', 'partial existing set rejected');
  check(failure?.safeResult?.apiOperations?.postCount === 0, 'partial existing set has zero POST');
}

async function testNetworkUnknownDoesNotRetry() {
  const mock = mockFetch({ failStage: 'item', networkFailure: true });
  let written;
  let failure;
  try { await runCatalogCreation({ accessToken: TOKEN, fetchImpl: mock.fetchImpl, writeResult: (value) => { written = value; } }); } catch (error) { failure = error; }
  const posts = mock.calls.filter((call) => call.options.method === 'POST');
  check(posts.length === 1, 'unknown POST is never retried');
  check(failure?.safeResult?.status === 'unknown_after_post' && written?.status === 'unknown_after_post', 'unknown state is recorded');
  check(mock.calls.filter((call) => call.url.includes('/v2/catalog/list?')).length === 2, 'one preflight GET and one confirmation GET');
}

async function testKnownRejectionDoesNotContinue() {
  const mock = mockFetch({ failStage: 'plan' });
  let failure;
  try { await runCatalogCreation({ accessToken: TOKEN, fetchImpl: mock.fetchImpl, writeResult: () => {} }); } catch (error) { failure = error; }
  check(failure?.safeResult?.status === 'rejected', 'known API rejection recorded');
  check(mock.calls.filter((call) => call.options.method === 'POST').length === 2, 'known rejection stops later POSTs');
  check(failure?.safeResult?.errorCode.includes('BAD_REQUEST'), 'safe Square error code retained');
  check(failure?.safeResult?.mutations?.approvedCatalogItem === 1 && failure?.safeResult?.mutations?.approvedCatalogItemVariation === 1 && failure?.safeResult?.mutations?.approvedSubscriptionPlan === 0, 'only confirmed mutations counted');
}

async function main() {
  await testCreateAndVerify();
  await testExistingDoesNotPost();
  await testPartialStops();
  await testNetworkUnknownDoesNotRetry();
  await testKnownRejectionDoesNotContinue();
  process.stdout.write(`square-sandbox-catalog-create-test: ${assertions}/${assertions} PASS\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});

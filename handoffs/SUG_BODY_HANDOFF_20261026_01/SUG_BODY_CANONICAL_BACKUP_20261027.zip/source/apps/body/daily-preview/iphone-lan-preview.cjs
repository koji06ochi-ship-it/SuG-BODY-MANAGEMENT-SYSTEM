'use strict';
// Token-gated private-LAN preview. No upload, AI call, payment, DB or public bind.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../../..');
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.mjs':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpeg':'image/jpeg','.jpg':'image/jpeg','.png':'image/png','.json':'application/json; charset=utf-8'};
function isPrivateHost(host){
 if(host==='127.0.0.1'||host==='::1')return true;
 const m=/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host||'');if(!m)return false;
 const p=m.slice(1).map(Number);if(p.some(n=>n>255))return false;
 return p[0]===10||(p[0]===172&&p[1]>=16&&p[1]<=31)||(p[0]===192&&p[1]===168);
}
function fileForRequest(url,token){
 let pathname;try{pathname=decodeURIComponent(new URL(url,'http://preview.local').pathname)}catch{return null}
 const prefix='/'+token+'/';if(!pathname.startsWith(prefix))return null;
 let relative=pathname.slice(prefix.length);if(relative.endsWith('/'))relative+='index.html';
 if(!relative.startsWith('apps/body/daily-preview/')&&!relative.startsWith('assets/walk-local/')&&relative!=='assets/quest/person-gps-core-20260905.js')return null;
 const file=path.resolve(root,relative);return file.startsWith(root+path.sep)?file:null;
}
function start(){
 const host=process.env.SUG_BODY_LAN_HOST||'',token=process.env.SUG_BODY_LAN_TOKEN||'',port=Number(process.env.SUG_BODY_LAN_PORT||4192);
 if(!isPrivateHost(host))throw Error('SUG_BODY_LAN_HOST must be loopback or an RFC1918 private IPv4 address.');
 if(!/^[A-Za-z0-9_.~-]{24,128}$/.test(token))throw Error('SUG_BODY_LAN_TOKEN must be 24-128 URL-safe characters.');
 if(!Number.isInteger(port)||port<1024||port>65535)throw Error('SUG_BODY_LAN_PORT must be 1024-65535.');
 const server=http.createServer((req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data: blob: https://tile.openstreetmap.org; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'");
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end()}
  const file=fileForRequest(req.url,token);if(!file){res.writeHead(404);return res.end()}
  fs.readFile(file,(error,bytes)=>{if(error){res.writeHead(404);return res.end()}res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');res.end(req.method==='HEAD'?undefined:bytes)});
 });
 server.listen(port,host,()=>console.log(`Private BODY preview: http://${host}:${port}/${token}/apps/body/daily-preview/index.html?test=1`));
 return server;
}
if(require.main===module)start();
module.exports={isPrivateHost,fileForRequest,start};

param(
  [ValidatePattern('^\d{4}-\d{2}-\d{2}$')]
  [string]$ApiVersion = '2026-09-16'
)

$ErrorActionPreference = 'Stop'
$createScript = Join-Path $PSScriptRoot 'square-sandbox-catalog-create.cjs'
$resultFile = Join-Path $PSScriptRoot 'square-sandbox-monthly-plan-result.json'
$secureToken = $null
$tokenPointer = [IntPtr]::Zero
$plainToken = $null
$process = $null
$priorLockReleased = $false

try {
  $Host.UI.RawUI.WindowTitle = 'S.u.G BODY - Square Sandbox Token Input'
  if (-not (Test-Path -LiteralPath $createScript -PathType Leaf)) {
    throw 'Square Sandbox作成スクリプトが見つかりません。'
  }
  $draftValidation = & node $createScript '--validate-draft'
  if ($LASTEXITCODE -ne 0 -or $draftValidation.Trim() -ne 'SQUARE_SANDBOX_FOUR_OBJECT_DRAFT_VALID') {
    throw '承認済み4オブジェクトの送信内容検証に失敗しました。'
  }
  if (Test-Path -LiteralPath $resultFile -PathType Leaf) {
    $priorResult = Get-Content -LiteralPath $resultFile -Raw | ConvertFrom-Json
    if ($priorResult.status -eq 'rejected' -and $priorResult.failedStage -eq 'item') {
      $priorLockReleased = $true
    }
  }

  Write-Host '============================================================' -ForegroundColor Yellow
  Write-Host ' S.u.G BODY / Square Sandbox Access Token 非表示入力' -ForegroundColor Yellow
  Write-Host '============================================================' -ForegroundColor Yellow
  Write-Host 'このタイトルの画面だけにSandbox Access Tokenを入力してください。'
  if ($priorLockReleased) {
    Write-Host '前回ロックは、追加承認済みItem Variationを含む4件検証PASSにより今回だけ解除しました。' -ForegroundColor Cyan
  }
  Write-Host '最初にCatalog GETで既存4件を確認し、作成済みならPOSTしません。'
  Write-Host '未作成の場合だけ、Item＋Item Variation→Plan→Plan Variationの順に作成します。'
  Write-Host '各作成後にGET確認し、失敗時は後続作成と再POSTを停止します。'
  Write-Host 'Production・Webhook・決済・Customer・Subscriptionには接続しません。'
  Write-Host 'トークンは画面表示・ファイル・ログ・引数・環境変数へ保存しません。'
  do {
    $secureToken = Read-Host 'ここへSandbox Access Tokenを貼り付けてEnter（入力は非表示）' -AsSecureString
    if ($secureToken.Length -eq 0) {
      Write-Host '入力が空です。この画面は入力待ちを継続します。' -ForegroundColor Yellow
      $secureToken.Dispose()
      $secureToken = $null
    }
  } while ($null -eq $secureToken)

  $tokenPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
  $plainToken = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($tokenPointer)

  $startInfo = [Diagnostics.ProcessStartInfo]::new()
  $startInfo.FileName = 'node'
  $startInfo.ArgumentList.Add($createScript)
  $startInfo.ArgumentList.Add('--api-version')
  $startInfo.ArgumentList.Add($ApiVersion)
  $startInfo.UseShellExecute = $false
  $startInfo.CreateNoWindow = $true
  $startInfo.RedirectStandardInput = $true
  $startInfo.RedirectStandardOutput = $true
  $startInfo.RedirectStandardError = $true

  $process = [Diagnostics.Process]::Start($startInfo)
  $process.StandardInput.WriteLine($plainToken)
  $process.StandardInput.Close()
  $plainToken = $null
  Write-Host 'トークンをメモリー内で受け取りました。GET事前確認を開始します。' -ForegroundColor Cyan

  $standardOutput = $process.StandardOutput.ReadToEnd()
  $standardError = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  if ($process.ExitCode -ne 0) {
    Write-Output $standardError
    throw 'Sandbox処理は安全停止しました。同じ操作を自動再試行しません。'
  }

  Write-Output $standardOutput
  Write-Host '伏字検証結果を square-sandbox-monthly-plan-result.json に保存しました。'
  Write-Host '処理完了。結果はこの画面に伏字だけで表示されています。' -ForegroundColor Green
}
finally {
  $plainToken = $null
  if ($tokenPointer -ne [IntPtr]::Zero) {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($tokenPointer)
  }
  if ($process) {
    $process.Dispose()
  }
  if ($secureToken) {
    $secureToken.Dispose()
  }
}

'use strict';
const a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const auth=require('../../../api/ai-auth.cjs'),core=require('../../../api/body-ai-core.cjs'),provider=require('../../../api/food-provider.cjs'),bodyHandler=require('../../../api/body-analyze.js');
let tests=0;function test(name,fn){fn();tests++;console.log('OK '+name)}
function token(secret,payload){const body=Buffer.from(JSON.stringify(payload)).toString('base64url');return body+'.'+crypto.createHmac('sha256',secret).update(body).digest('base64url')}
test('AI provider has no implicit fallback',()=>a.throws(()=>provider.config({OPENAI_API_KEY:'x',OPENAI_FOOD_MODEL:'x'}),/AI_PROVIDER_REQUIRED/));
test('member token scope is enforced',()=>{const secret='a'.repeat(32),authorization='Bearer '+token(secret,{sub:'m1',exp:Math.floor(Date.now()/1000)+60,scope:['body:coach']});a.equal(auth.authorize({headers:{authorization}},{BODY_AI_SESSION_SECRET:secret},'body:coach').sub,'m1');a.throws(()=>auth.authorize({headers:{authorization}},{BODY_AI_SESSION_SECRET:secret},'body:food-photo'),/AI_AUTH_SCOPE/)});
test('daily summary removes identity and unknown fields',()=>{const x=core.sanitize({day:'2026-10-26',goal:'maintain',name:'本人名',metrics:{steps:{value:5000,source:'healthkit_native'},diagnosis:{value:1}},mealSummary:[]});a.equal(x.metrics.steps.value,5000);a.equal(x.name,undefined);a.equal(x.metrics.diagnosis,undefined)});
test('AI observations need real evidence fields',()=>{const input=core.sanitize({day:'2026-10-26',goal:'maintain',metrics:{steps:{value:5000,source:'healthkit_native'}}}),x=core.normalize({summary:'候補',observations:[{text:'歩数',confidence:.7,evidenceFields:['steps']},{text:'創作',confidence:1,evidenceFields:['sleepHours']}],suggestions:[],missingData:[]},input);a.equal(x.observations.length,1);a.deepEqual(x.observations[0].evidenceFields,['steps'])});
const root=path.resolve(__dirname,'../../..'),health=fs.readFileSync(path.join(root,'ios/SuGMember/HealthKitManager.swift'),'utf8'),view=fs.readFileSync(path.join(root,'ios/SuGMember/MemberWebView.swift'),'utf8'),content=fs.readFileSync(path.join(root,'ios/SuGMember/ContentView.swift'),'utf8'),project=fs.readFileSync(path.join(root,'ios/project.yml'),'utf8');
test('HealthKit missing cumulative data stays optional',()=>{a.match(health,/@Published var steps: Int\?/);a.match(health,/continuation\.resume\(returning: nil\)/);a.doesNotMatch(health,/stats\?\.sumQuantity\(\)\?\.doubleValue\(for: unit\) \?\? 0/)});
test('native bridge marks measured zero and sample identities',()=>{a.match(view,/"zeroIsMeasured":true/);a.match(view,/payload\["sampleIds"\]/);a.match(view,/measuredFields/)});
test('iOS BODY tab targets normal BODY',()=>{a.match(content,/apps\/body\/index\.html/);a.doesNotMatch(content,/best-of-miss/)});
test('signing team remains unconfigured',()=>a.doesNotMatch(project,/DEVELOPMENT_TEAM/));
function response(){return{code:0,body:null,setHeader(){},status(n){this.code=n;return this},json(x){this.body=x;return this},end(){return this}}}
async function asyncTest(name,fn){await fn();tests++;console.log('OK '+name)}
(async()=>{
 const secret='b'.repeat(32),authorization='Bearer '+token(secret,{sub:'m1',exp:Math.floor(Date.now()/1000)+60,scope:['body:coach']}),saved={...process.env},savedFetch=global.fetch;
 try{
  Object.assign(process.env,{BODY_COACH_AI_ENABLED:'true',BODY_COACH_AI_COST_APPROVED:'true',BODY_COACH_AI_PROVIDER:'openai',OPENAI_COACH_MODEL:'fixture',OPENAI_API_KEY:'fixture',BODY_AI_SESSION_SECRET:secret});
  let calls=0;global.fetch=async()=>{calls++;return{ok:true,json:async()=>({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify({summary:'歩数の記録があります',observations:[{text:'歩数を受信',confidence:.9,evidenceFields:['steps']}],suggestions:[{title:'継続',reason:'歩数あり',action:'体調を確認して続ける',requiresConfirmation:true}],missingData:['sleepHours']})}]}]})}};
  await asyncTest('authorized daily analysis reaches selected mock provider once',async()=>{const r=response();await bodyHandler({method:'POST',headers:{authorization},body:{day:'2026-10-26',goal:'maintain',metrics:{steps:{value:5000,source:'healthkit_native'}}}},r);a.equal(r.code,200);a.equal(calls,1);a.equal(r.body.observations[0].evidenceFields[0],'steps')});
 }finally{global.fetch=savedFetch;for(const k of Object.keys(process.env))if(!(k in saved))delete process.env[k];Object.assign(process.env,saved)}
 console.log(JSON.stringify({tests,result:'PASS',externalRequests:0,mockProviderCalls:1,xcodeBuild:false,physicalDevice:false}));
})().catch(error=>{console.error(error);process.exitCode=1});

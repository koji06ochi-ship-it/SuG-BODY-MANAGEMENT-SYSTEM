'use strict';
const a=require('node:assert/strict'),P=require('./prescription-core.js');require('./training-core.js');require('./daily-core.js');const C=global.BodyDailyCore;
let count=0;function test(name,fn){fn();count++;console.log('OK '+name)}
const date='2026-10-26',entry={name:'BP',sets:3,reps:8};
const base=()=>({profile:{weight:'65',goal:'筋肉をつけたい'},days:{[date]:{sleep:'7',steps:'4000',fatigue:'少ない',stress:'少ない',pain:'なし'}},foods:[],cares:[],workouts:[]});
const w=(id,day,extra={})=>({id,name:'BP',condition:'bar total',day,at:day+'T10:00:00Z',sets:[{kg:50,reps:10},{kg:50,reps:10},{kg:50,reps:10}],effort:'前回より余裕あり',movement:'同じ条件で保てた',pain:'なし',...extra});
function calc(d,step=2.5){return P.build(d,date,[entry],step)}
test('empty recovery does not prescribe',()=>{const d=base();d.days={};a.equal(calc(d).mode,'input');a.equal(calc(d).entries.length,0)});
test('pain has priority over missing data',()=>{const d=base();d.days[date]={pain:'あり'};a.equal(calc(d).mode,'care')});
test('rest overrides training',()=>{const d=base();d.days[date].activityChoice='今日は休む';a.equal(calc(d).mode,'recovery')});
test('short sleep reduces initial sets',()=>{const d=base();d.days[date].sleep='5';a.equal(calc(d).entries[0].sets.length,1)});
test('unrecorded steps blocks progression, zero steps is known',()=>{const d=base();d.days[date].steps='';a.equal(calc(d).allowIncrease,false);d.days[date].steps='0';a.equal(calc(d).allowIncrease,true)});
test('activity uses prior dates not future or missing days',()=>{const d=base();for(const x of ['23','24','25'])d.days['2026-10-'+x]={steps:'1000'};d.days['2026-10-27']={steps:'200000'};a.equal(calc(d).stepsAverage,1000);a.equal(calc(d).mode,'light')});
test('single workout never increases',()=>{const d=base();d.workouts=[w('a','2026-10-23')];a.equal(calc(d).entries[0].status,'維持')});
test('two distinct comparable sessions propose increment',()=>{const d=base();d.workouts=[w('a','2026-10-23'),w('b','2026-10-25')];a.equal(calc(d).entries[0].sets[0].kg,52.5);a.equal(calc(d).entries[0].sets[0].reps,8);a.equal(calc(d).entries[0].status,'増量候補')});
test('same day double record cannot qualify',()=>{const d=base();d.workouts=[w('a','2026-10-25'),w('b','2026-10-25')];a.equal(calc(d).entries[0].status,'維持')});
test('different equipment cannot qualify',()=>{const d=base();d.workouts=[w('a','2026-10-23',{condition:'machine'}),w('b','2026-10-25')];a.equal(calc(d).entries[0].status,'維持')});
test('missing feedback cannot qualify',()=>{const d=base();d.workouts=[w('a','2026-10-23'),w('b','2026-10-25',{pain:''})];a.equal(calc(d).entries[0].status,'維持')});
test('greater than 10 percent increment withheld',()=>{const d=base();d.workouts=[w('a','2026-10-23'),w('b','2026-10-25')];a.equal(calc(d,10).entries[0].status,'維持')});
test('pain in last workout blocks weight',()=>{const d=base();d.workouts=[w('a','2026-10-25',{pain:'あり・負荷を変更'})];a.equal(calc(d).entries[0].sets.length,0)});
test('form breakdown reduces sets without increase',()=>{const d=base();d.workouts=[w('a','2026-10-25',{movement:'途中で崩れた'})];a.equal(calc(d).entries[0].sets.length,2);a.equal(calc(d).entries[0].sets[0].kg,50)});
test('531 history never gets ordinary overload',()=>{const d=base();d.workouts=[w('a','2026-10-25',{planId:'p',planWeek:'1'})];a.equal(calc(d).entries[0].status,'計画を確認')});
test('body weight never determines initial lifted weight',()=>{const d=base();d.profile.weight='120';a.equal(calc(d).entries[0].sets[0].kg,null)});
test('saved record survives JSON and drives next prescription',()=>{const d=base();d.workouts=[w('a','2026-10-23'),w('b','2026-10-25')];const restored=C.parseImport(JSON.stringify(C.envelope(d,true)),true);a.deepEqual(calc(restored).entries,calc(d).entries)});
test('build leaves source records unchanged',()=>{const d=base();d.workouts=[w('a','2026-10-25')];const original=JSON.stringify(d);calc(d);a.equal(JSON.stringify(d),original)});
test('old sessions do not qualify for increase',()=>{const d=base();d.workouts=[w('a','2026-09-20'),w('b','2026-09-25')];a.equal(calc(d).entries[0].status,'維持')});
test('goal and time set cap applies to previous records',()=>{const d=base();d.workouts=[w('a','2026-10-23'),w('b','2026-10-25')];a.equal(P.build(d,date,[{...entry,sets:2}],2.5).entries[0].sets.length,2)});
console.log(JSON.stringify({status:'PASS',tests:count,scope:'prescription logic and existing JSON roundtrip; not browser or clinical validation'}));

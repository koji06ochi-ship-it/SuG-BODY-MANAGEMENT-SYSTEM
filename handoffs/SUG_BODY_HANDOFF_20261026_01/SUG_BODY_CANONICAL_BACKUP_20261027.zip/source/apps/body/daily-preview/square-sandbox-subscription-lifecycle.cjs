'use strict';

const path = require('path');
const { DEFAULT_OUTPUT, runLifecycle } = require(path.resolve(__dirname, '../../../api/body-square-sandbox-subscription-lifecycle.cjs'));

function parseArgs(argv) {
  let apiVersion = '2026-09-16';
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--api-version') {
      apiVersion = argv[index + 1] || '';
      index += 1;
    } else {
      throw new Error('UNSUPPORTED_ARGUMENT');
    }
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(apiVersion)) throw new Error('SQUARE_API_VERSION_INVALID');
  return { apiVersion };
}

async function readToken(stream = process.stdin) {
  stream.setEncoding('utf8');
  let data = '';
  for await (const chunk of stream) {
    data += chunk;
    if (data.length > 4096) throw new Error('SQUARE_SANDBOX_TOKEN_TOO_LONG');
  }
  return data.replace(/[\r\n]+$/g, '');
}

async function main() {
  const { apiVersion } = parseArgs(process.argv.slice(2));
  const accessToken = await readToken();
  const result = await runLifecycle({ accessToken, apiVersion });
  process.stdout.write(`${JSON.stringify({
    ok: result.status === 'sandbox_lifecycle_verified',
    status: result.status,
    resultFile: DEFAULT_OUTPUT,
    customerIdMasked: result.customer?.idMasked || '',
    subscriptionIdMasked: result.subscription?.idMasked || '',
    invoiceStatus: result.invoice?.status || '',
    paymentStatus: result.payment?.status || '',
    amount: result.payment?.amount || 0,
    currency: result.payment?.currency || '',
    cancellationScheduled: result.cancellation?.scheduled === true,
    totalRefunded: result.refundSummary?.totalRefunded || 0,
    productionConnected: result.productionConnected
  }, null, 2)}\n`);
}

if (require.main === module) {
  main().catch((error) => {
    const safe = error?.safeResult;
    process.stderr.write(`${JSON.stringify({
      ok: false,
      status: safe?.status || 'failed',
      errorCode: safe?.errorCode || 'SQUARE_SANDBOX_LIFECYCLE_FAILED',
      resultFile: DEFAULT_OUTPUT,
      productionConnected: false
    })}\n`);
    process.exitCode = 1;
  });
}

module.exports = { main, parseArgs, readToken };

# 食事写真 Gemini / OpenAI対応（2026-10-26）

## 今回の変更
既存api/food-analyze.jsを維持し、api/food-provider.cjsでGemini/OpenAIの要求・応答を変換する。新しいAPI入口は増設しない。
BODY_FOOD_AI_PROVIDERで明示選択。両方の設定を残せる。失敗・キー不足・上限で別プロバイダーへ切り替えない。自動再試行なし。
GeminiはgenerateContent、inlineData、JSON構造化結果。OpenAIは既存Responses形式を再使用。
両方の結果を既存の料理・量・kcal・PFC・不確実性表示へ接続。不明はnull、未完了／安全ブロック結果を成功扱いしない。使用provider/modelを候補原文に保持。
サーバーの有効化・費用確認は無効のまま。モデルも勝手に選ばず明示設定を要求する。

## 設定の確認範囲
このプロセス環境ではGEMINI_API_KEY、GOOGLE_API_KEY、OPENAI_API_KEYは未設定。作業コピー直下と.vercel内の.env候補にも対象設定は見つからなかった。
確認は設定名・有無だけで、キー値の表示や外部送信なし。公開Vercel/Googleのアカウント・Windows側・残高や利用枠は未確認。ユーザーが両サービスを持っていないとは扱わない。

## 検証
dual-ai-test.cjs 13項目通過。すべてローカルの架空応答、実API0回。
Google形式、OpenAI形式、共通結果、null、未完了拒否、無効時送信0、勝手な切替なしを確認。
初回構文確認でGemini要求の閉じ括弧が不足して停止。補正後に構文確認・13項目を完走。
前回food-connection-testのAPIモックはOpenAI単独・旧ゲート前提。今回のサーバー挙動はdual-ai-testを正とし、前回10項目を新APIの通過数として流用しない。
実写真・ブラウザー・iPhoneでのAI解析は未確認。公開・Windows適用・課金なし。

## 必要な設定（値・キーは記載しない）
BODY_FOOD_AI_PROVIDER=gemini または openai
GEMINI_API_KEY（またはGOOGLE_API_KEY） / GEMINI_FOOD_MODEL
OPENAI_API_KEY / OPENAI_FOOD_MODEL
BODY_FOOD_AI_ENABLED、BODY_FOOD_AI_COST_APPROVEDは現在無効。これらは実際の無料枠・残高を照会する仕組みではない。
有効化前には既存公開環境の設定と利用枠・認証／利用制限を確認する。現時点では無料動作も接続成功も断定しない。

## Google公式仕様
https://ai.google.dev/gemini-api/docs/generate-content/image-understanding
https://ai.google.dev/gemini-api/docs/generate-content/structured-output

'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const api = path.resolve(__dirname, '../../../api');
const planCore = require(path.join(api, 'body-square-monthly-plan.cjs'));
const lifecycle = require(path.join(api, 'body-subscription-entitlement.cjs'));
const sessions = require(path.join(api, 'body-session-service.cjs'));
const service = require(path.join(api, 'body-square-webhook-service.cjs'));
const transaction = require(path.join(api, 'body-entitlement-transaction.cjs'));
const squareClient = require(path.join(api, 'body-square-client.cjs'));
const repositoryCore = require(path.join(api, 'body-supabase-repository.cjs'));

let passed = 0;
async function check(name, fn) {
  try { await fn(); passed += 1; console.log('PASS', name); }
  catch (error) { console.error('FAIL', name, error); process.exitCode = 1; }
}

const binding = { accountId: 'account-1', productId: 'body_general', subscriptionId: 'sub-1', planVariationId: 'variation-1', customerId: 'customer-1' };
const subscription = { id: 'sub-1', customer_id: 'customer-1', plan_variation_id: 'variation-1', status: 'ACTIVE', charged_through_date: '2026-11-25' };
const paidInvoice = { id: 'invoice-1', subscription_id: 'sub-1', status: 'PAID', payment_requests: [{ computed_amount_money: { amount: 1480, currency: 'JPY' }, total_completed_amount_money: { amount: 1480, currency: 'JPY' } }] };
const event = (type, id) => ({ event_id: 'event-' + type + '-' + id, type, data: { id, object: type.startsWith('invoice.') ? { invoice: { id } } : { subscription: { id } } } });

(async () => {
  await check('monthly plan is JPY 1480 tax-included and indefinite', () => {
    const draft = planCore.catalogDraft();
    const result = planCore.validateCatalog(draft.plan, draft.variation, draft.item);
    assert.equal(result.ready, true);
    assert.equal(planCore.PLAN.amount, 1480);
    assert.equal(planCore.PLAN.currency, 'JPY');
    assert.equal(planCore.PLAN.cadence, 'MONTHLY');
    assert.equal(planCore.PLAN.periods, null);
    assert.equal(planCore.PLAN.taxIncluded, true);
    assert.equal(planCore.PLAN.automaticRenewal, true);
  });
  await check('wrong price is rejected before Sandbox mutation', () => {
    const draft = planCore.catalogDraft();
    draft.variation.subscription_plan_variation_data.phases[0].pricing.price_money.amount = 1481;
    assert.equal(planCore.validateCatalog(draft.plan, draft.variation, draft.item).ready, false);
  });
  await check('all purchase renewal failure cancel and refund events are required', () => {
    const readiness = planCore.webhookReadiness(planCore.REQUIRED_WEBHOOK_EVENTS);
    assert.equal(Object.values(readiness).every(Boolean), true);
    for (const name of ['invoice.payment_made', 'invoice.scheduled_charge_failed', 'subscription.updated', 'invoice.refunded']) assert.equal(readiness[name], true);
  });
  await check('initial paid invoice grants body_general through paid date', () => {
    const mutation = lifecycle.planLifecycleMutation({ event: event('invoice.payment_made', 'invoice-1'), subscription, invoice: paidInvoice, binding });
    assert.equal(mutation.action, 'grant_period');
    assert.equal(mutation.productId, 'body_general');
    assert.equal(mutation.validUntil, '2026-11-25');
    assert.equal(mutation.billingStatus, 'paid');
  });
  await check('renewal extends the paid period', () => {
    const renewed = { ...subscription, charged_through_date: '2026-12-25' };
    const invoice = { ...paidInvoice, id: 'invoice-2' };
    const mutation = lifecycle.planLifecycleMutation({ event: event('invoice.payment_made', 'invoice-2'), subscription: renewed, invoice, binding });
    assert.equal(mutation.validUntil, '2026-12-25');
    assert.equal(mutation.invoiceId, 'invoice-2');
  });
  await check('wrong monthly amount never grants access', () => {
    const invoice = JSON.parse(JSON.stringify(paidInvoice));
    invoice.payment_requests[0].computed_amount_money.amount = 1479;
    invoice.payment_requests[0].total_completed_amount_money.amount = 1479;
    assert.throws(() => lifecycle.planLifecycleMutation({ event: event('invoice.payment_made', 'invoice-1'), subscription, invoice, binding }), /AMOUNT_OR_CURRENCY/);
  });
  await check('scheduled charge failure preserves an already paid period', () => {
    const failed = { id: 'invoice-2', subscription_id: 'sub-1', status: 'UNPAID' };
    const mutation = lifecycle.planLifecycleMutation({ event: event('invoice.scheduled_charge_failed', 'invoice-2'), subscription, invoice: failed, binding });
    assert.equal(mutation.action, 'payment_failed');
    assert.equal(mutation.preserveExistingAccess, true);
    assert.equal(mutation.validUntil, '2026-11-25');
  });
  await check('cancellation schedules expiry at paid-through date', () => {
    const canceled = { ...subscription, status: 'CANCELED' };
    const mutation = lifecycle.planLifecycleMutation({ event: event('subscription.updated', 'sub-1'), subscription: canceled, binding });
    assert.equal(mutation.action, 'schedule_expiry');
    assert.equal(mutation.validUntil, '2026-11-25');
  });
  await check('full refund revokes and partial refund requires review', () => {
    const full = lifecycle.planLifecycleMutation({ event: event('invoice.refunded', 'invoice-1'), subscription, invoice: { ...paidInvoice, status: 'REFUNDED' }, binding });
    const partial = lifecycle.planLifecycleMutation({ event: event('invoice.refunded', 'invoice-1'), subscription, invoice: { ...paidInvoice, status: 'PARTIALLY_REFUNDED' }, binding });
    assert.equal(full.action, 'revoke');
    assert.equal(partial.action, 'manual_review');
    assert.equal(partial.preserveExistingAccess, true);
  });
  await check('expired entitlement does not grant body_general', async () => {
    const repository = { verifyUser: async () => ({ id: 'account-1' }), getProfile: async () => ({ id: 'account-1', role: 'body_customer' }), getEntitlement: async () => ({ status: 'active', valid_until: '2026-10-25' }) };
    const result = await sessions.accessStatus({ accessToken: 'member-token', repository, now: new Date('2026-10-26T03:00:00Z') });
    assert.equal(result.allowed, false);
    assert.deepEqual(result.permissions, []);
  });
  await check('valid entitlement grants only body_general', async () => {
    const repository = { verifyUser: async () => ({ id: 'account-1' }), getProfile: async () => ({ id: 'account-1', role: 'body_customer' }), getEntitlement: async () => ({ status: 'active', valid_until: '2026-11-25' }) };
    const result = await sessions.accessStatus({ accessToken: 'member-token', repository, now: new Date('2026-10-26T03:00:00Z') });
    assert.deepEqual(result.permissions, ['body_general']);
    assert.equal(result.permissions.some((x) => /trainer|admin|coach/.test(x)), false);
  });
  await check('signed invoice webhook refetches Square canonical objects and applies once', async () => {
    const webhookEvent = event('invoice.payment_made', 'invoice-1');
    const rawBody = JSON.stringify(webhookEvent), notificationUrl = 'https://example.test/api/body-square-webhook', signatureKey = '12345678901234567890123456789012';
    const signature = crypto.createHmac('sha256', signatureKey).update(notificationUrl + rawBody).digest('base64');
    let applied = 0;
    const result = await service.processWebhook({ rawBody, signature, notificationUrl, signatureKey, square: { getInvoice: async () => paidInvoice, getSubscription: async () => subscription }, repository: { getSubscriptionBindingBySubscriptionId: async () => binding, applyAtomic: async (_event, mutation) => { applied += 1; assert.equal(mutation.validUntil, '2026-11-25'); return { status: 'applied' }; } } });
    assert.equal(result.status, 'applied');
    assert.equal(applied, 1);
  });
  await check('invalid webhook signature changes no entitlement', async () => {
    const webhookEvent = event('invoice.payment_made', 'invoice-1');
    let applied = 0;
    await assert.rejects(() => service.processWebhook({ rawBody: JSON.stringify(webhookEvent), signature: 'bad', notificationUrl: 'https://example.test', signatureKey: '12345678901234567890123456789012', square: {}, repository: { applyAtomic: async () => { applied += 1; } } }), /signature/);
    assert.equal(applied, 0);
  });
  await check('duplicate event produces no second grant', async () => {
    const seen = new Set(); let grants = 0;
    const store = { applyAtomic: async (squareEvent) => { if (seen.has(squareEvent.event_id)) return { status: 'duplicate', eventId: squareEvent.event_id }; seen.add(squareEvent.event_id); grants += 1; return { status: 'applied', eventId: squareEvent.event_id }; } };
    const input = { event: { event_id: 'duplicate', type: 'invoice.payment_made' }, mutation: { requireAtomicDeduplication: true, lifecycle: 'subscription' }, store };
    assert.equal((await transaction.applyEntitlement(input)).status, 'applied');
    assert.equal((await transaction.applyEntitlement(input)).status, 'duplicate');
    assert.equal(grants, 1);
  });
  await check('subscription and invoice canonical reads use Sandbox GET only', async () => {
    const calls = [];
    const fetchMock = async (url, options) => { calls.push({ url, method: options.method }); return { ok: true, status: 200, text: async () => JSON.stringify(url.includes('/invoices/') ? { invoice: paidInvoice } : { subscription }) }; };
    const client = squareClient.createClient({ accessToken: 'mock', environment: 'sandbox', apiVersion: '2026-09-16' }, fetchMock);
    await client.getSubscription('sub-1');
    await client.getInvoice('invoice-1');
    assert.equal(calls.every((call) => call.method === 'GET'), true);
    assert.equal(calls.every((call) => call.url.includes('connect.squareupsandbox.com')), true);
  });
  await check('atomic DB boundary carries subscription period fields without executing a DB change', async () => {
    let rpcBody = null;
    const fetchMock = async (_url, options) => { rpcBody = JSON.parse(options.body); return { ok: true, status: 200, text: async () => JSON.stringify([{ status: 'applied' }]) }; };
    const repository = repositoryCore.createRepository({ url: 'https://project.supabase.co', publishableKey: 'public', serviceRoleKey: 'server', subscriptionsTable: 'body_square_subscriptions' }, fetchMock);
    await repository.applyAtomic({ event_id: 'period-event', type: 'invoice.payment_made' }, { action: 'grant_period', accountId: 'account-1', productId: 'body_general', subscriptionId: 'sub-1', invoiceId: 'invoice-1', validUntil: '2026-11-25', billingStatus: 'paid' });
    assert.equal(rpcBody.p_subscription_id, 'sub-1');
    assert.equal(rpcBody.p_valid_until, '2026-11-25');
    assert.equal(rpcBody.p_billing_status, 'paid');
    assert.equal(rpcBody.p_preserve_access, false);
  });
  console.log(JSON.stringify({ passed, total: 16, scope: 'JPY 1480 monthly subscription lifecycle mocks; no Square mutation, payment, DB or Production access' }));
})().catch((error) => { console.error(error); process.exitCode = 1; });

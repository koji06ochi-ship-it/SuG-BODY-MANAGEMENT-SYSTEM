'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
let passed=0;function test(name,fn){fn();passed++;console.log('PASS',name)}
test('daily preview loads Supabase bridge before integration scripts',()=>{const s=read('apps/body/daily-preview/index.html');assert(s.indexOf('body-supabase-bridge.js')<s.indexOf('integration-ui.js'));assert(read('apps/body/daily-preview/integration-ui.js').includes("connections.src='connections-ui.js'"));});
test('preview and normal BODY share the same auth storage key',()=>{assert(read('apps/body/daily-preview/body-supabase-bridge.js').includes("STORAGE_KEY='sug-body-management-v4-auth'"));assert(read('apps/body/body-cloud-sync-v27.52.js').includes('storageKey:AUTH_STORAGE_KEY'));});
test('browser bridge keeps server access disabled until configured',()=>{const s=read('apps/body/daily-preview/body-supabase-bridge.js');assert(s.includes("if(access.enabled!==true)access.enabled=false"));assert(!s.includes('SERVICE_ROLE'));});
test('SAFE map exposes local text filtering without adding a new map',()=>{const s=read('assets/walk-local/walk-safe-map.mjs');for(const token of ['safeSearchTerm','safeSearchClear','facilitySearchText(f)','defibrillator:\'AED 自動体外式除細動器\'','createFacilityProvider'])assert(s.includes(token));});
test('SAFE result opens the existing marker and map',()=>{const s=read('assets/walk-local/walk-safe-map.mjs');assert(s.includes('map.setView([f.lat,f.lng]'));assert(s.includes('marker.openPopup()'));});
test('external AI providers remain server gated',()=>{const s=read('api/food-provider.cjs');for(const token of ['BODY_COACH_AI','BODY_FOOD_AI','GEMINI_API_KEY','OPENAI_API_KEY'])assert(s.includes(token));});
console.log(JSON.stringify({passed,total:passed}));

'use strict';

const assert = require('assert');
const { runAudit, classify } = require('./square-sandbox-audit.cjs');

const calls = [];
function response(body, status = 200) {
  return { ok: status >= 200 && status < 300, status, text: async () => JSON.stringify(body) };
}

async function fetchMock(url, options) {
  calls.push({ url, method: options.method, authorization: options.headers.Authorization });
  if (url.endsWith('/v2/merchants')) {
    return response({ merchant: [{ id: 'SANDBOX-MERCHANT-7788', country: 'JP', currency: 'JPY', status: 'ACTIVE' }] });
  }
  if (url.includes('/v2/catalog/list?')) {
    return response({ objects: [
      { type: 'ITEM', id: 'ITEM1', item_data: { name: 'S.u.G BODY', product_type: 'REGULAR', variations: [{}] } },
      { type: 'ITEM', id: 'ITEM2', item_data: { name: '既存サービス', product_type: 'REGULAR' } }
    ] });
  }
  if (url.includes('/v2/webhooks/subscriptions?')) {
    return response({ subscriptions: [{
      id: 'HOOK1', enabled: true,
      event_types: ['payment.updated', 'refund.updated'],
      notification_url: 'https://private.example.test/webhook'
    }] });
  }
  throw new Error('UNEXPECTED_URL');
}

(async () => {
  let written = null;
  const secret = 'sandbox-secret-never-store';
  const result = await runAudit({
    accessToken: secret,
    fetchImpl: fetchMock,
    checkedAt: '2026-10-26T00:00:00.000Z',
    writeResult: (value) => { written = value; }
  });

  assert.equal(result.apiStatus, 'connected');
  assert.equal(result.environment, 'sandbox');
  assert.equal(result.merchant.idMasked, '***7788');
  assert.equal(result.catalog.itemCount, 2);
  assert.equal(result.webhooks.count, 1);
  assert.equal(result.webhooks.enabledCount, 1);
  assert.equal(result.webhooks.requiredEvents['payment.updated'], true);
  assert.equal(result.webhooks.requiredEvents['refund.updated'], true);
  assert.equal(result.production.connected, false);
  assert.equal(calls.every((call) => call.method === 'GET'), true);
  assert.equal(calls.every((call) => call.url.includes('squareupsandbox.com')), true);
  assert.equal(JSON.stringify(written).includes(secret), false);
  assert.equal(JSON.stringify(written).includes('SANDBOX-MERCHANT-7788'), false);
  assert.equal(JSON.stringify(written).includes('private.example.test'), false);
  assert.equal(classify({ merchant: null, catalog: null, webhooks: 'error' }), 'partial');

  const denied = await runAudit({
    accessToken: secret,
    fetchImpl: async () => response({ errors: [{ code: 'UNAUTHORIZED', detail: 'do not persist this response detail' }] }, 401),
    writeResult: () => {}
  });
  assert.equal(denied.apiStatus, 'failed');
  assert.equal(denied.errors.merchant, 'SQUARE_READ_FAILED_HTTP_401_CODES_UNAUTHORIZED');
  assert.equal(JSON.stringify(denied).includes('do not persist'), false);
  assert.equal(JSON.stringify(denied).includes(secret), false);
  console.log(JSON.stringify({ passed: 18, total: 18, scope: 'Square Sandbox audit mock; GET only; safe HTTP diagnostics; no secret persistence or network' }));
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

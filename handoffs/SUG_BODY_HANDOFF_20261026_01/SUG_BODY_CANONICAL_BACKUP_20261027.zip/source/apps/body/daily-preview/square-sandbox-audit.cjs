'use strict';

const fs = require('fs');
const path = require('path');
const { createClient } = require(path.resolve(__dirname, '../../../api/body-square-client.cjs'));
const { inspect } = require(path.resolve(__dirname, '../../../api/body-square-readiness.cjs'));

const OUTPUT_FILE = path.resolve(__dirname, 'square-sandbox-readiness-result.json');

function validateApiVersion(value) {
  const version = String(value || '2026-09-16');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(version)) throw new Error('SQUARE_API_VERSION_INVALID');
  return version;
}

function classify(errors) {
  const states = Object.values(errors || {}).map((value) => value === null);
  if (states.length && states.every(Boolean)) return 'connected';
  if (states.some(Boolean)) return 'partial';
  return 'failed';
}

async function runAudit({
  accessToken,
  apiVersion = '2026-09-16',
  expectedWebhookUrl = '',
  fetchImpl = fetch,
  checkedAt = new Date().toISOString(),
  writeResult = (value) => fs.writeFileSync(OUTPUT_FILE, JSON.stringify(value, null, 2) + '\n', 'utf8')
}) {
  const token = String(accessToken || '').trim();
  if (!token) throw new Error('SQUARE_SANDBOX_TOKEN_REQUIRED');

  const client = createClient({
    accessToken: token,
    environment: 'sandbox',
    apiVersion: validateApiVersion(apiVersion)
  }, fetchImpl);
  const readiness = await inspect({ client, expectedWebhookUrl });
  const result = {
    checkedAt,
    scope: 'Square Sandbox read-only API',
    apiStatus: classify(readiness.errors),
    developerApplication: {
      existence: 'user_confirmed',
      sandboxCredentialsScreen: 'user_confirmed',
      productionCredentialsScreen: 'user_confirmed'
    },
    ...readiness,
    production: {
      connected: false,
      reason: '本番トークン未登録・本番API未実行'
    },
    mutations: {
      productCreated: false,
      webhookRegistered: false,
      paymentExecuted: false,
      databaseChanged: false
    }
  };

  const serialized = JSON.stringify(result);
  if (serialized.includes(token)) throw new Error('SECRET_OUTPUT_BLOCKED');
  writeResult(result);
  return result;
}

function parseArgs(argv) {
  let apiVersion = '2026-09-16';
  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--api-version') {
      apiVersion = argv[index + 1] || '';
      index += 1;
    } else {
      throw new Error('UNSUPPORTED_ARGUMENT');
    }
  }
  return { apiVersion: validateApiVersion(apiVersion) };
}

async function readToken(stream = process.stdin) {
  stream.setEncoding('utf8');
  let data = '';
  for await (const chunk of stream) {
    data += chunk;
    if (data.length > 4096) throw new Error('SQUARE_SANDBOX_TOKEN_TOO_LONG');
  }
  return data.replace(/[\r\n]+$/g, '');
}

async function main() {
  const { apiVersion } = parseArgs(process.argv.slice(2));
  const accessToken = await readToken();
  const result = await runAudit({ accessToken, apiVersion });
  process.stdout.write(JSON.stringify({
    ok: result.apiStatus === 'connected',
    apiStatus: result.apiStatus,
    resultFile: OUTPUT_FILE,
    merchantIdMasked: result.merchant.idMasked,
    catalogItemCount: result.catalog.itemCount,
    webhookCount: result.webhooks.count,
    webhookEnabledCount: result.webhooks.enabledCount
  }, null, 2) + '\n');
}

if (require.main === module) {
  main().catch(() => {
    process.stderr.write('SQUARE_SANDBOX_READONLY_AUDIT_FAILED\n');
    process.exitCode = 1;
  });
}

module.exports = { OUTPUT_FILE, classify, runAudit };

param(
  [ValidatePattern('^\d{4}-\d{2}-\d{2}$')]
  [string]$ApiVersion = '2026-09-16'
)

$ErrorActionPreference = 'Stop'
$lifecycleScript = Join-Path $PSScriptRoot 'square-sandbox-subscription-lifecycle.cjs'
$secureToken = $null
$tokenPointer = [IntPtr]::Zero
$plainToken = $null
$process = $null

try {
  $Host.UI.RawUI.WindowTitle = 'S.u.G BODY - Square Sandbox Lifecycle Token Input'
  if (-not (Test-Path -LiteralPath $lifecycleScript -PathType Leaf)) {
    throw 'Square Sandbox契約検証スクリプトが見つかりません。'
  }

  Write-Host '============================================================' -ForegroundColor Yellow
  Write-Host ' S.u.G BODY / Square Sandbox契約検証' -ForegroundColor Yellow
  Write-Host '============================================================' -ForegroundColor Yellow
  Write-Host 'このタイトルの画面だけにSandbox Access Tokenを入力してください。'
  Write-Host '既存Catalog 4件をGET確認し、変更・再作成しません。'
  Write-Host '架空Customer 1件、SandboxテストCard 1件、Subscription 1件だけを重複防止付きで作成します。'
  Write-Host '初回1,480円請求、期間末解約、1円部分返金後の残額返金をSandbox内で検証します。'
  Write-Host 'Production・Webhook登録・公開・DB・実カード・実在顧客には接続しません。'
  Write-Host 'トークンは画面表示・ファイル・ログ・引数・環境変数へ保存しません。'
  do {
    $secureToken = Read-Host 'ここへSandbox Access Tokenを貼り付けてEnter（入力は非表示）' -AsSecureString
    if ($secureToken.Length -eq 0) {
      Write-Host '入力が空です。この画面は入力待ちを継続します。' -ForegroundColor Yellow
      $secureToken.Dispose()
      $secureToken = $null
    }
  } while ($null -eq $secureToken)

  $tokenPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
  $plainToken = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($tokenPointer)

  $startInfo = [Diagnostics.ProcessStartInfo]::new()
  $startInfo.FileName = 'node'
  $startInfo.ArgumentList.Add($lifecycleScript)
  $startInfo.ArgumentList.Add('--api-version')
  $startInfo.ArgumentList.Add($ApiVersion)
  $startInfo.UseShellExecute = $false
  $startInfo.CreateNoWindow = $true
  $startInfo.RedirectStandardInput = $true
  $startInfo.RedirectStandardOutput = $true
  $startInfo.RedirectStandardError = $true

  $process = [Diagnostics.Process]::Start($startInfo)
  $process.StandardInput.WriteLine($plainToken)
  $process.StandardInput.Close()
  $plainToken = $null
  Write-Host 'トークンをメモリー内で受け取りました。Sandbox限定検証を開始します。' -ForegroundColor Cyan

  $standardOutput = $process.StandardOutput.ReadToEnd()
  $standardError = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  if ($process.ExitCode -ne 0) {
    Write-Output $standardError
    throw 'Sandbox契約検証は安全停止しました。同じ操作を自動再試行しません。'
  }

  Write-Output $standardOutput
  Write-Host '伏字結果を square-sandbox-subscription-lifecycle-result.json に保存しました。'
  Write-Host '処理完了。結果は伏字だけで表示されています。' -ForegroundColor Green
}
finally {
  $plainToken = $null
  if ($tokenPointer -ne [IntPtr]::Zero) {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($tokenPointer)
  }
  if ($process) { $process.Dispose() }
  if ($secureToken) { $secureToken.Dispose() }
}

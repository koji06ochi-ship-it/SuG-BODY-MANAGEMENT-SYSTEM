param(
  [ValidatePattern('^\d{4}-\d{2}-\d{2}$')]
  [string]$ApiVersion = '2026-09-16'
)

$ErrorActionPreference = 'Stop'
$auditScript = Join-Path $PSScriptRoot 'square-sandbox-audit.cjs'
$secureToken = $null
$tokenPointer = [IntPtr]::Zero
$plainToken = $null
$process = $null

try {
  $Host.UI.RawUI.WindowTitle = 'S.u.G BODY - Square Sandbox GET Only'
  if (-not (Test-Path -LiteralPath $auditScript -PathType Leaf)) {
    throw 'Square Sandbox監査スクリプトが見つかりません。'
  }

  Write-Host '============================================================' -ForegroundColor Yellow
  Write-Host ' S.u.G BODY / Square Sandbox GET Only' -ForegroundColor Yellow
  Write-Host '============================================================' -ForegroundColor Yellow
  Write-Host 'この画面は読み取り専用です。POST・作成・変更を行いません。'
  Write-Host 'Sandbox Access Tokenは画面表示・ファイル保存・コマンド引数への記録を行いません。'
  do {
    $secureToken = Read-Host 'ここへSandbox Access Tokenを貼り付けてEnter（入力は非表示）' -AsSecureString
    if ($secureToken.Length -eq 0) {
      Write-Host '入力が空です。この画面は入力待ちを継続します。' -ForegroundColor Yellow
      $secureToken.Dispose()
      $secureToken = $null
    }
  } while ($null -eq $secureToken)

  $tokenPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
  $plainToken = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($tokenPointer)

  $startInfo = [Diagnostics.ProcessStartInfo]::new()
  $startInfo.FileName = 'node'
  $startInfo.ArgumentList.Add($auditScript)
  $startInfo.ArgumentList.Add('--api-version')
  $startInfo.ArgumentList.Add($ApiVersion)
  $startInfo.UseShellExecute = $false
  $startInfo.CreateNoWindow = $true
  $startInfo.RedirectStandardInput = $true
  $startInfo.RedirectStandardOutput = $true
  $startInfo.RedirectStandardError = $true

  $process = [Diagnostics.Process]::Start($startInfo)
  $process.StandardInput.WriteLine($plainToken)
  $process.StandardInput.Close()
  $plainToken = $null
  Write-Host 'トークンをメモリー内で受け取りました。GET確認を開始します。' -ForegroundColor Cyan

  $standardOutput = $process.StandardOutput.ReadToEnd()
  $process.StandardError.ReadToEnd() | Out-Null
  $process.WaitForExit()
  if ($process.ExitCode -ne 0) {
    throw 'Sandbox読み取り確認に失敗しました。入力値とSquare Sandboxの利用状態を確認してください。'
  }

  Write-Output $standardOutput
  Write-Host '伏字結果を square-sandbox-readiness-result.json に保存しました。'
  Write-Host '読み取り専用確認が完了しました。' -ForegroundColor Green
}
finally {
  $plainToken = $null
  if ($tokenPointer -ne [IntPtr]::Zero) {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($tokenPointer)
  }
  if ($process) {
    $process.Dispose()
  }
  if ($secureToken) {
    $secureToken.Dispose()
  }
}

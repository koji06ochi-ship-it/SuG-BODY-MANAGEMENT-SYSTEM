'use strict';

const PLAN = Object.freeze({
  productId: 'body_general',
  planName: 'S.u.G BODY 一般向け',
  variationName: '月額1,480円（税込）',
  amount: 1480,
  currency: 'JPY',
  cadence: 'MONTHLY',
  periods: null,
  pricingType: 'STATIC',
  taxIncluded: true,
  canProrate: false,
  automaticRenewal: true
});

const REQUIRED_WEBHOOK_EVENTS = Object.freeze([
  'subscription.created',
  'subscription.updated',
  'invoice.payment_made',
  'invoice.scheduled_charge_failed',
  'invoice.canceled',
  'invoice.refunded',
  'payment.updated',
  'refund.updated'
]);

function catalogDraft({ itemTempId = '#sug-body-general-item', itemVariationTempId = '#sug-body-general-item-monthly', planTempId = '#sug-body-general-plan', variationTempId = '#sug-body-general-monthly' } = {}) {
  const itemVariation = {
    type: 'ITEM_VARIATION',
    id: itemVariationTempId,
    present_at_all_locations: true,
    item_variation_data: {
      item_id: itemTempId,
      name: '一般向け月額',
      pricing_type: 'FIXED_PRICING',
      price_money: { amount: PLAN.amount, currency: PLAN.currency }
    }
  };
  return {
    reviewOnly: true,
    item: {
      type: 'ITEM',
      id: itemTempId,
      present_at_all_locations: true,
      item_data: {
        name: 'S.u.G BODY',
        product_type: 'REGULAR',
        is_taxable: false,
        variations: [itemVariation]
      }
    },
    itemVariation,
    plan: {
      type: 'SUBSCRIPTION_PLAN',
      id: planTempId,
      present_at_all_locations: true,
      subscription_plan_data: { name: PLAN.planName, eligible_item_ids: [itemTempId], all_items: false }
    },
    variation: {
      type: 'SUBSCRIPTION_PLAN_VARIATION',
      id: variationTempId,
      present_at_all_locations: true,
      subscription_plan_variation_data: {
        name: PLAN.variationName,
        subscription_plan_id: planTempId,
        can_prorate: PLAN.canProrate,
        phases: [{
          ordinal: 0,
          cadence: PLAN.cadence,
          pricing: { type: PLAN.pricingType, price_money: { amount: PLAN.amount, currency: PLAN.currency } }
        }]
      }
    }
  };
}

function validateCatalog(plan, variation, item, itemVariation = item?.item_data?.variations?.[0]) {
  const planData = plan?.subscription_plan_data || {};
  const variationData = variation?.subscription_plan_variation_data || {};
  const itemVariationData = itemVariation?.item_variation_data || {};
  const itemVariationMoney = itemVariationData.price_money || {};
  const phase = Array.isArray(variationData.phases) ? variationData.phases[0] : null;
  const money = phase?.pricing?.price_money || phase?.pricing?.price || {};
  const checks = {
    itemType: item?.type === 'ITEM',
    itemName: item?.item_data?.name === 'S.u.G BODY',
    itemNotTaxable: item?.item_data?.is_taxable === false && (!Array.isArray(item?.item_data?.tax_ids) || item.item_data.tax_ids.length === 0),
    itemVariationType: itemVariation?.type === 'ITEM_VARIATION',
    itemVariationName: itemVariationData.name === '一般向け月額',
    itemVariationParent: itemVariationData.item_id === item?.id,
    itemVariationPricing: itemVariationData.pricing_type === 'FIXED_PRICING',
    itemVariationAmount: Number(itemVariationMoney.amount) === PLAN.amount,
    itemVariationCurrency: itemVariationMoney.currency === PLAN.currency,
    planType: plan?.type === 'SUBSCRIPTION_PLAN',
    planName: planData.name === PLAN.planName,
    eligibleItem: Array.isArray(planData.eligible_item_ids) && planData.eligible_item_ids.length === 1 && planData.eligible_item_ids[0] === item?.id && planData.all_items === false,
    variationType: variation?.type === 'SUBSCRIPTION_PLAN_VARIATION',
    variationName: variationData.name === PLAN.variationName,
    linkedPlan: Boolean(variationData.subscription_plan_id && variationData.subscription_plan_id === plan?.id),
    onePhase: Array.isArray(variationData.phases) && variationData.phases.length === 1,
    monthly: phase?.cadence === PLAN.cadence,
    indefinite: phase && (phase.periods === undefined || phase.periods === null),
    staticPrice: phase?.pricing?.type === PLAN.pricingType,
    amount: Number(money.amount) === PLAN.amount,
    currency: money.currency === PLAN.currency,
    noProration: variationData.can_prorate === false
  };
  return { ready: Object.values(checks).every(Boolean), checks };
}

function webhookReadiness(eventTypes = []) {
  const available = new Set(eventTypes.map(String));
  return Object.fromEntries(REQUIRED_WEBHOOK_EVENTS.map((event) => [event, available.has(event)]));
}

module.exports = { PLAN, REQUIRED_WEBHOOK_EVENTS, catalogDraft, validateCatalog, webhookReadiness };

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { listCatalog, resolveExactSet } = require('./body-square-sandbox-catalog-create.cjs');
const { PLAN, REQUIRED_WEBHOOK_EVENTS } = require('./body-square-monthly-plan.cjs');
const lifecycle = require('./body-subscription-entitlement.cjs');
const transaction = require('./body-entitlement-transaction.cjs');
const signatureCore = require('./square-signature.cjs');

const SANDBOX_BASE = 'https://connect.squareupsandbox.com';
const CUSTOMER_REFERENCE = 'sug-body-sandbox-lifecycle-v1';
const CARD_REFERENCE = 'sug-body-sandbox-card-v1';
const SOURCE_NAME = 'S.u.G BODY Sandbox Lifecycle';
const DEFAULT_OUTPUT = path.resolve(__dirname, '../apps/body/daily-preview/square-sandbox-subscription-lifecycle-result.json');

function maskId(value) {
  const id = String(value || '');
  return id ? `***${id.slice(-4)}` : '';
}

function safeCodes(body) {
  return Array.isArray(body?.errors)
    ? body.errors.map((entry) => String(entry?.code || '')).filter((code) => /^[A-Z0-9_]+$/.test(code)).slice(0, 5)
    : [];
}

function endpointLabel(method, requestPath) {
  const plain = requestPath.split('?')[0];
  if (plain === '/v2/customers/search') return '/v2/customers/search';
  if (plain === '/v2/subscriptions/search') return '/v2/subscriptions/search';
  if (/^\/v2\/subscriptions\/[^/]+\/events$/.test(plain)) return '/v2/subscriptions/{subscription_id}/events';
  if (/^\/v2\/customers\/[^/]+$/.test(plain)) return '/v2/customers/{customer_id}';
  if (/^\/v2\/subscriptions\/[^/]+\/cancel$/.test(plain)) return '/v2/subscriptions/{subscription_id}/cancel';
  if (/^\/v2\/subscriptions\/[^/]+$/.test(plain)) return '/v2/subscriptions/{subscription_id}';
  if (/^\/v2\/invoices\/[^/]+$/.test(plain)) return '/v2/invoices/{invoice_id}';
  if (/^\/v2\/orders\/[^/]+$/.test(plain)) return '/v2/orders/{order_id}';
  if (/^\/v2\/payments\/[^/]+$/.test(plain)) return '/v2/payments/{payment_id}';
  if (/^\/v2\/refunds\/[^/]+$/.test(plain)) return '/v2/refunds/{refund_id}';
  if (plain === '/v2/catalog/list') return '/v2/catalog/list';
  if (plain === '/v2/cards') return '/v2/cards';
  return plain;
}

function createRequester({ accessToken, apiVersion, fetchImpl, operations }) {
  async function request(method, requestPath, body) {
    let response;
    try {
      response = await fetchImpl(`${SANDBOX_BASE}${requestPath}`, {
        method,
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Square-Version': apiVersion,
          Accept: 'application/json',
          ...(body ? { 'Content-Type': 'application/json' } : {})
        },
        ...(body ? { body: JSON.stringify(body) } : {}),
        redirect: 'error',
        signal: AbortSignal.timeout(15000)
      });
    } catch {
      operations.push({ method, endpoint: endpointLabel(method, requestPath), httpStatus: 0 });
      const error = new Error('SQUARE_NETWORK_FAILED');
      error.isNetwork = true;
      throw error;
    }
    operations.push({ method, endpoint: endpointLabel(method, requestPath), httpStatus: Number(response.status || 0) });
    let parsed = null;
    try {
      const text = await response.text();
      parsed = text ? JSON.parse(text) : {};
    } catch {
      parsed = null;
    }
    if (!response.ok) {
      const codes = safeCodes(parsed);
      const error = new Error(`SQUARE_HTTP_${response.status || 0}${codes.length ? `_CODES_${codes.join(',')}` : ''}`);
      error.httpStatus = Number(response.status || 0);
      error.squareCodes = codes;
      throw error;
    }
    if (!parsed || typeof parsed !== 'object') throw new Error('SQUARE_INVALID_JSON');
    return parsed;
  }
  return {
    get: (requestPath) => request('GET', requestPath),
    post: (requestPath, body) => request('POST', requestPath, body)
  };
}

function moneyTotals(invoice) {
  const requests = Array.isArray(invoice?.payment_requests) ? invoice.payment_requests : [];
  return {
    computed: requests.reduce((sum, row) => sum + Number(row?.computed_amount_money?.amount || 0), 0),
    completed: requests.reduce((sum, row) => sum + Number(row?.total_completed_amount_money?.amount || 0), 0),
    currencies: [...new Set(requests.flatMap((row) => [row?.computed_amount_money?.currency, row?.total_completed_amount_money?.currency]).filter(Boolean))]
  };
}

function addMonth(dateText) {
  const [year, month, day] = String(dateText).split('-').map(Number);
  if (!year || !month || !day) throw new Error('VALID_UNTIL_REQUIRED');
  const nextMonth = new Date(Date.UTC(year, month, 1));
  const targetDay = Math.min(day, new Date(Date.UTC(nextMonth.getUTCFullYear(), nextMonth.getUTCMonth() + 1, 0)).getUTCDate());
  return `${nextMonth.getUTCFullYear()}-${String(nextMonth.getUTCMonth() + 1).padStart(2, '0')}-${String(targetDay).padStart(2, '0')}`;
}

function createMemoryStore(binding) {
  const seen = new Set();
  const state = { status: 'inactive', validUntil: null, billingStatus: 'inactive', productId: null, accountId: binding.accountId, auditCount: 0 };
  return {
    state,
    async applyAtomic(event, mutation) {
      if (seen.has(event.event_id)) return { status: 'duplicate', eventId: event.event_id, entitlement: { ...state } };
      if (mutation.accountId !== binding.accountId || mutation.productId !== PLAN.productId) throw new Error('LOCAL_OWNER_OR_PRODUCT_MISMATCH');
      seen.add(event.event_id);
      if (mutation.action === 'grant_period') {
        state.status = 'active';
        state.validUntil = mutation.validUntil;
        state.billingStatus = mutation.billingStatus;
      } else if (mutation.action === 'payment_failed' || mutation.action === 'manual_review') {
        state.billingStatus = mutation.billingStatus;
      } else if (mutation.action === 'schedule_expiry') {
        state.status = 'active';
        state.validUntil = mutation.validUntil;
        state.billingStatus = mutation.billingStatus;
      } else if (mutation.action === 'revoke') {
        state.status = 'revoked';
        state.billingStatus = mutation.billingStatus;
      } else {
        throw new Error('LOCAL_MUTATION_UNSUPPORTED');
      }
      state.productId = mutation.productId;
      state.auditCount += 1;
      return { status: 'applied', eventId: event.event_id, entitlement: { ...state } };
    }
  };
}

async function applyMockLifecycle({ subscription, invoice, customerId, planVariationId }) {
  const binding = {
    accountId: 'sandbox-body-general-test-account',
    productId: PLAN.productId,
    subscriptionId: subscription.id,
    planVariationId,
    customerId
  };
  const store = createMemoryStore(binding);
  const makeEvent = (type, suffix) => ({ event_id: `mock-${suffix}`, type });
  const apply = async (event, canonicalSubscription, canonicalInvoice) => {
    const mutation = lifecycle.planLifecycleMutation({ event, subscription: canonicalSubscription, invoice: canonicalInvoice, binding });
    if (!mutation) return { status: 'observed' };
    return transaction.applyEntitlement({ event, mutation, store });
  };

  const paidDate = subscription.paid_until_date || subscription.charged_through_date;
  const firstEvent = makeEvent('invoice.payment_made', 'initial-paid');
  const initial = await apply(firstEvent, subscription, invoice);
  const duplicate = await apply(firstEvent, subscription, invoice);
  const renewedDate = addMonth(paidDate);
  const renewedSubscription = { ...subscription, paid_until_date: renewedDate, charged_through_date: renewedDate, status: 'ACTIVE' };
  const renewedInvoice = { ...invoice, id: `${invoice.id}-mock-renewal`, status: 'PAID' };
  const renewal = await apply(makeEvent('invoice.payment_made', 'renewal-paid'), renewedSubscription, renewedInvoice);
  const failedInvoice = { ...invoice, id: `${invoice.id}-mock-failed`, status: 'UNPAID' };
  const failure = await apply(makeEvent('invoice.scheduled_charge_failed', 'charge-failed'), renewedSubscription, failedInvoice);
  const scheduled = await apply(makeEvent('subscription.updated', 'cancel-scheduled'), { ...renewedSubscription, canceled_date: renewedDate }, null);
  const partial = await apply(makeEvent('invoice.refunded', 'partial-refund'), renewedSubscription, { ...invoice, status: 'PARTIALLY_REFUNDED' });
  const full = await apply(makeEvent('invoice.refunded', 'full-refund'), renewedSubscription, { ...invoice, status: 'REFUNDED' });

  const rawBody = JSON.stringify({ event_id: 'mock-signature', type: 'invoice.payment_made', data: { id: invoice.id } });
  const notificationUrl = 'https://sandbox.example.test/api/body-square-webhook';
  const signatureKey = 'sandbox-local-mock-signature-key-32';
  const validSignature = crypto.createHmac('sha256', signatureKey).update(notificationUrl + rawBody).digest('base64');
  const signatureAccepted = signatureCore.verifySignature({ rawBody, signature: validSignature, notificationUrl, signatureKey });
  const invalidSignatureRejected = !signatureCore.verifySignature({ rawBody, signature: 'invalid', notificationUrl, signatureKey });

  return {
    storage: 'local_memory_only',
    account: 'non_personal_sandbox_test_account',
    initial: { status: initial.status, validUntil: paidDate },
    duplicate: { status: duplicate.status, secondGrantPrevented: duplicate.status === 'duplicate' },
    renewal: { mode: 'mock', status: renewal.status, validUntil: renewedDate },
    paymentFailure: { mode: 'mock', status: failure.status, preservedValidUntil: store.state.validUntil },
    cancellation: { mode: 'mock', status: scheduled.status, expiresAt: renewedDate },
    partialRefund: { mode: 'mock', status: partial.status, manualReview: true },
    fullRefund: { mode: 'mock', status: full.status, finalEntitlementStatus: store.state.status },
    signature: { mode: 'mock', validAccepted: signatureAccepted, invalidRejected: invalidSignatureRejected },
    auditCount: store.state.auditCount,
    finalState: { status: store.state.status, validUntil: store.state.validUntil, billingStatus: store.state.billingStatus, productId: store.state.productId }
  };
}

function baseResult(checkedAt) {
  return {
    checkedAt,
    scope: 'Square Sandbox monthly subscription lifecycle',
    environment: 'sandbox',
    productionConnected: false,
    status: 'preflight',
    catalog: null,
    customer: null,
    card: null,
    subscription: null,
    invoice: null,
    payment: null,
    cancellation: null,
    refunds: [],
    webhooks: { checkedThisRun: false, actualEndpointCreated: false, actualReceived: false, subscriptionsFound: null, requiredEventsCovered: false },
    entitlement: null,
    apiOperations: [],
    mutations: { customer: 0, card: 0, subscription: 0, cancellation: 0, refund: 0, webhook: 0, database: 0, production: 0 }
  };
}

function safeErrorCode(error) {
  return String(error?.message || 'SQUARE_SANDBOX_LIFECYCLE_FAILED').replace(/[^A-Z0-9_,]/g, '_').slice(0, 180);
}

function safeWrite(writeResult, result, token) {
  const serialized = JSON.stringify(result);
  if (token && serialized.includes(token)) throw new Error('SECRET_OUTPUT_BLOCKED');
  if (/Bearer\s+/i.test(serialized) || /connect\.squareup\.com/i.test(serialized)) throw new Error('SECRET_OR_PRODUCTION_OUTPUT_BLOCKED');
  writeResult(result);
}

async function poll(check, { attempts = 12, delayMs = 2500, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)) } = {}) {
  let last = null;
  for (let index = 0; index < attempts; index += 1) {
    last = await check();
    if (last?.ready) return last;
    if (index + 1 < attempts) await sleep(delayMs);
  }
  return last || { ready: false };
}

async function runLifecycle({
  accessToken,
  apiVersion = '2026-09-16',
  fetchImpl = fetch,
  checkedAt = new Date().toISOString(),
  expectedMerchantSuffix = '4DBN',
  writeResult = (value) => fs.writeFileSync(DEFAULT_OUTPUT, `${JSON.stringify(value, null, 2)}\n`, 'utf8'),
  sleep
} = {}) {
  const token = String(accessToken || '').trim();
  if (!token) throw new Error('SQUARE_SANDBOX_TOKEN_REQUIRED');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(apiVersion)) throw new Error('SQUARE_API_VERSION_INVALID');
  const result = baseResult(checkedAt);
  const requester = createRequester({ accessToken: token, apiVersion, fetchImpl, operations: result.apiOperations });

  try {
    const merchantBody = await requester.get('/v2/merchants');
    const merchants = Array.isArray(merchantBody.merchant) ? merchantBody.merchant : Array.isArray(merchantBody.merchants) ? merchantBody.merchants : [];
    if (merchants.length !== 1) throw new Error('SANDBOX_MERCHANT_COUNT_MISMATCH');
    const merchant = merchants[0];
    if (!String(merchant.id || '').endsWith(expectedMerchantSuffix)) throw new Error('SANDBOX_MERCHANT_MISMATCH');
    if (merchant.status !== 'ACTIVE' || merchant.country !== 'JP' || merchant.currency !== 'JPY' || !merchant.main_location_id) throw new Error('SANDBOX_MERCHANT_NOT_READY');

    const catalogObjects = await listCatalog(requester);
    const catalog = resolveExactSet(catalogObjects);
    if (catalog.state !== 'valid') throw new Error('APPROVED_CATALOG_FOUR_OBJECTS_REQUIRED');
    result.catalog = {
      verified: true,
      itemIdMasked: maskId(catalog.item.id),
      planVariationIdMasked: maskId(catalog.variation.id),
      amount: PLAN.amount,
      currency: PLAN.currency,
      cadence: PLAN.cadence,
      modified: false
    };

    const searchCustomerBody = await requester.post('/v2/customers/search', {
      query: { filter: { reference_id: { exact: CUSTOMER_REFERENCE } } },
      limit: 2,
      count: true
    });
    let customers = Array.isArray(searchCustomerBody.customers) ? searchCustomerBody.customers : [];
    if (customers.length > 1) throw new Error('SANDBOX_TEST_CUSTOMER_DUPLICATE');
    let customer = customers[0] || null;
    let customerCreated = false;
    if (!customer) {
      const created = await requester.post('/v2/customers', {
        idempotency_key: 'sug-body-customer-lifecycle-v1',
        given_name: 'SUG',
        family_name: 'BODY Sandbox Test',
        company_name: 'S.u.G BODY Sandbox Test',
        email_address: 'sug-body-square-sandbox@example.com',
        reference_id: CUSTOMER_REFERENCE
      });
      customer = created.customer;
      customerCreated = true;
      result.mutations.customer = 1;
    }
    if (!customer?.id || customer.reference_id !== CUSTOMER_REFERENCE || !customer.email_address || (!customer.given_name && !customer.company_name)) throw new Error('SANDBOX_TEST_CUSTOMER_INVALID');
    result.customer = { idMasked: maskId(customer.id), created: customerCreated, fictitious: true, referenceMatched: true, piiUsed: false };

    const cardQuery = new URLSearchParams({ customer_id: customer.id, reference_id: CARD_REFERENCE, include_disabled: 'true' });
    const cardBody = await requester.get(`/v2/cards?${cardQuery}`);
    let cards = Array.isArray(cardBody.cards) ? cardBody.cards : [];
    if (cards.length > 1) throw new Error('SANDBOX_TEST_CARD_DUPLICATE');
    let card = cards[0] || null;
    let cardCreated = false;
    if (!card) {
      const created = await requester.post('/v2/cards', {
        idempotency_key: 'sug-body-card-lifecycle-v1',
        source_id: 'cnon:card-nonce-ok',
        card: { customer_id: customer.id, cardholder_name: 'SUG BODY SANDBOX TEST', reference_id: CARD_REFERENCE }
      });
      card = created.card;
      cardCreated = true;
      result.mutations.card = 1;
    }
    if (!card?.id || card.customer_id !== customer.id || card.reference_id !== CARD_REFERENCE || card.enabled !== true) throw new Error('SANDBOX_TEST_CARD_INVALID');
    result.card = { idMasked: maskId(card.id), created: cardCreated, sandboxTestValue: true, enabled: true, realCardUsed: false };

    const searchSubscriptions = await requester.post('/v2/subscriptions/search', {
      query: { filter: { location_ids: [merchant.main_location_id], customer_ids: [customer.id], source_names: [SOURCE_NAME] } },
      include: ['actions'],
      limit: 10
    });
    const matches = (Array.isArray(searchSubscriptions.subscriptions) ? searchSubscriptions.subscriptions : [])
      .filter((entry) => entry.plan_variation_id === catalog.variation.id && entry.customer_id === customer.id);
    if (matches.length > 1) throw new Error('SANDBOX_TEST_SUBSCRIPTION_DUPLICATE');
    let subscription = matches[0] || null;
    let subscriptionCreated = false;
    if (!subscription) {
      const created = await requester.post('/v2/subscriptions', {
        idempotency_key: 'sug-body-subscription-lifecycle-v1',
        location_id: merchant.main_location_id,
        plan_variation_id: catalog.variation.id,
        customer_id: customer.id,
        card_id: card.id,
        timezone: 'Asia/Tokyo',
        source: { name: SOURCE_NAME }
      });
      subscription = created.subscription;
      subscriptionCreated = true;
      result.mutations.subscription = 1;
    }
    if (!subscription?.id || subscription.customer_id !== customer.id || subscription.plan_variation_id !== catalog.variation.id || subscription.card_id !== card.id) throw new Error('SANDBOX_TEST_SUBSCRIPTION_INVALID');

    result.subscription = {
      idMasked: maskId(subscription.id),
      created: subscriptionCreated,
      status: String(subscription.status || ''),
      planVariationIdMasked: maskId(subscription.plan_variation_id),
      duplicateFree: true,
      paidUntil: subscription.paid_until_date || subscription.charged_through_date || null
    };

    const billed = await poll(async () => {
      const currentBody = await requester.get(`/v2/subscriptions/${encodeURIComponent(subscription.id)}`);
      const current = currentBody.subscription;
      if (current?.status === 'DEACTIVATED') return { ready: false, terminal: true, subscription: current };
      const invoiceId = Array.isArray(current?.invoice_ids) ? current.invoice_ids[0] : '';
      if (!invoiceId) return { ready: false, subscription: current };
      const invoiceBody = await requester.get(`/v2/invoices/${encodeURIComponent(invoiceId)}`);
      const invoice = invoiceBody.invoice;
      if (!invoice?.order_id || invoice.status !== 'PAID') return { ready: false, subscription: current, invoice };
      const orderBody = await requester.get(`/v2/orders/${encodeURIComponent(invoice.order_id)}`);
      const tenders = Array.isArray(orderBody.order?.tenders) ? orderBody.order.tenders : [];
      const paymentId = String(tenders.find((entry) => entry?.payment_id)?.payment_id || '');
      if (!paymentId) return { ready: false, subscription: current, invoice };
      const paymentBody = await requester.get(`/v2/payments/${encodeURIComponent(paymentId)}`);
      const payment = paymentBody.payment;
      return { ready: payment?.status === 'COMPLETED', subscription: current, invoice, payment };
    }, { sleep });
    if (!billed?.ready) {
      const current = billed?.subscription || subscription;
      result.subscription = {
        ...result.subscription,
        status: String(current?.status || ''),
        paidUntil: current?.paid_until_date || current?.charged_through_date || null,
        invoiceCount: Array.isArray(current?.invoice_ids) ? current.invoice_ids.length : 0
      };
      const eventBody = await requester.get(`/v2/subscriptions/${encodeURIComponent(subscription.id)}/events?limit=100`);
      const events = Array.isArray(eventBody.subscription_events) ? eventBody.subscription_events : [];
      result.subscription.events = events.map((entry) => ({
        type: String(entry?.subscription_event_type || ''),
        effectiveDate: String(entry?.effective_date || ''),
        infoCode: String(entry?.info?.code || '')
      }));
      if (current?.status === 'DEACTIVATED') throw new Error('SANDBOX_SUBSCRIPTION_DEACTIVATED_WITHOUT_INITIAL_INVOICE');
      throw new Error('SANDBOX_INITIAL_BILLING_NOT_COMPLETED');
    }
    subscription = billed.subscription;
    const invoice = billed.invoice;
    const payment = billed.payment;
    const totals = moneyTotals(invoice);
    const paymentMoney = payment.amount_money || payment.total_money || {};
    if (invoice.subscription_id !== subscription.id || totals.computed !== 1480 || totals.completed !== 1480 || totals.currencies.length !== 1 || totals.currencies[0] !== 'JPY') throw new Error('SANDBOX_INVOICE_AMOUNT_MISMATCH');
    if (Number(paymentMoney.amount) !== 1480 || paymentMoney.currency !== 'JPY' || payment.status !== 'COMPLETED') throw new Error('SANDBOX_PAYMENT_AMOUNT_MISMATCH');
    const paidUntil = subscription.paid_until_date || subscription.charged_through_date;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(paidUntil || ''))) throw new Error('SANDBOX_PAID_UNTIL_MISSING');
    result.subscription = { idMasked: maskId(subscription.id), created: subscriptionCreated, status: subscription.status, planVariationIdMasked: maskId(subscription.plan_variation_id), duplicateFree: true, paidUntil };
    result.invoice = { idMasked: maskId(invoice.id), status: invoice.status, amount: totals.completed, currency: totals.currencies[0], subscriptionLinked: true };
    result.payment = { idMasked: maskId(payment.id), status: payment.status, amount: Number(paymentMoney.amount), currency: paymentMoney.currency, actualSandbox: true };

    result.entitlement = await applyMockLifecycle({ subscription, invoice, customerId: customer.id, planVariationId: catalog.variation.id });

    const webhooksBody = await requester.get('/v2/webhooks/subscriptions?include_disabled=true&limit=100');
    const webhookRows = Array.isArray(webhooksBody.subscriptions) ? webhooksBody.subscriptions : [];
    const enabledEvents = new Set(webhookRows.filter((entry) => entry.enabled === true).flatMap((entry) => entry.event_types || []));
    result.webhooks = {
      checkedThisRun: true,
      actualEndpointCreated: false,
      actualReceived: false,
      subscriptionsFound: webhookRows.length,
      requiredEventsCovered: REQUIRED_WEBHOOK_EVENTS.every((name) => enabledEvents.has(name)),
      mode: 'mock_signature_and_local_dispatch_only',
      publicHttpsApprovalRequired: true
    };

    if (!subscription.canceled_date) {
      const canceledBody = await requester.post(`/v2/subscriptions/${encodeURIComponent(subscription.id)}/cancel`, null);
      subscription = canceledBody.subscription || subscription;
      result.mutations.cancellation = 1;
    }
    const canceledRead = await requester.get(`/v2/subscriptions/${encodeURIComponent(subscription.id)}`);
    subscription = canceledRead.subscription;
    if (!subscription?.canceled_date) throw new Error('SANDBOX_CANCELLATION_NOT_SCHEDULED');
    result.cancellation = { actualSandbox: true, scheduled: true, status: subscription.status, canceledDate: subscription.canceled_date, accessUntil: subscription.paid_until_date || subscription.charged_through_date || subscription.canceled_date };

    const currentPaymentBody = await requester.get(`/v2/payments/${encodeURIComponent(payment.id)}`);
    const alreadyRefunded = Number(currentPaymentBody.payment?.refunded_money?.amount || 0);
    if (![0, 1, 1480].includes(alreadyRefunded)) throw new Error('SANDBOX_UNEXPECTED_REFUND_STATE');
    if (alreadyRefunded === 0) {
      const partialBody = await requester.post('/v2/refunds', {
        idempotency_key: 'sug-body-partial-refund-v1',
        payment_id: payment.id,
        amount_money: { amount: 1, currency: 'JPY' },
        reason: 'S.u.G BODY Sandbox partial refund lifecycle test'
      });
      if (!partialBody.refund?.id) throw new Error('SANDBOX_PARTIAL_REFUND_MISSING');
      result.mutations.refund += 1;
      result.refunds.push({ kind: 'partial', idMasked: maskId(partialBody.refund.id), amount: 1, currency: 'JPY', status: String(partialBody.refund.status || ''), actualSandbox: true });
    } else if (alreadyRefunded === 1) {
      result.refunds.push({ kind: 'partial', amount: 1, currency: 'JPY', status: 'existing', actualSandbox: true });
    }

    const partialState = await poll(async () => {
      const invoiceBody = await requester.get(`/v2/invoices/${encodeURIComponent(invoice.id)}`);
      return { ready: invoiceBody.invoice?.status === 'PARTIALLY_REFUNDED' || invoiceBody.invoice?.status === 'REFUNDED', invoice: invoiceBody.invoice };
    }, { attempts: 8, delayMs: 1500, sleep });
    if (!partialState?.ready) throw new Error('SANDBOX_PARTIAL_REFUND_NOT_OBSERVED');

    const afterPartialPayment = await requester.get(`/v2/payments/${encodeURIComponent(payment.id)}`);
    const refundedAfterPartial = Number(afterPartialPayment.payment?.refunded_money?.amount || 0);
    if (refundedAfterPartial === 1) {
      const remainingBody = await requester.post('/v2/refunds', {
        idempotency_key: 'sug-body-remaining-refund-v1',
        payment_id: payment.id,
        amount_money: { amount: 1479, currency: 'JPY' },
        reason: 'S.u.G BODY Sandbox full-period refund completion'
      });
      if (!remainingBody.refund?.id) throw new Error('SANDBOX_REMAINING_REFUND_MISSING');
      result.mutations.refund += 1;
      result.refunds.push({ kind: 'remaining_to_full', idMasked: maskId(remainingBody.refund.id), amount: 1479, currency: 'JPY', status: String(remainingBody.refund.status || ''), actualSandbox: true });
    } else if (refundedAfterPartial !== 1480) {
      throw new Error('SANDBOX_PARTIAL_REFUND_AMOUNT_MISMATCH');
    }

    const fullState = await poll(async () => {
      const invoiceBody = await requester.get(`/v2/invoices/${encodeURIComponent(invoice.id)}`);
      const paymentBody = await requester.get(`/v2/payments/${encodeURIComponent(payment.id)}`);
      const refunded = Number(paymentBody.payment?.refunded_money?.amount || 0);
      return { ready: invoiceBody.invoice?.status === 'REFUNDED' && refunded === 1480, invoice: invoiceBody.invoice, refunded };
    }, { attempts: 8, delayMs: 1500, sleep });
    if (!fullState?.ready) throw new Error('SANDBOX_FULL_REFUND_NOT_OBSERVED');
    result.refundSummary = { actualSandbox: true, partialObserved: partialState.invoice?.status === 'PARTIALLY_REFUNDED', finalInvoiceStatus: fullState.invoice.status, totalRefunded: fullState.refunded, currency: 'JPY', entitlementPolicy: 'partial_manual_review_full_revoke' };

    result.status = 'sandbox_lifecycle_verified';
    safeWrite(writeResult, result, token);
    return result;
  } catch (error) {
    result.status = 'stopped';
    result.errorCode = safeErrorCode(error);
    safeWrite(writeResult, result, token);
    error.safeResult = result;
    throw error;
  }
}

module.exports = {
  CARD_REFERENCE,
  CUSTOMER_REFERENCE,
  DEFAULT_OUTPUT,
  SANDBOX_BASE,
  SOURCE_NAME,
  addMonth,
  applyMockLifecycle,
  createMemoryStore,
  createRequester,
  maskId,
  moneyTotals,
  poll,
  runLifecycle
};

'use strict';
function config(env,scope='food'){
 const prefix=scope==='coach'?'BODY_COACH_AI':'BODY_FOOD_AI',provider=env[prefix+'_PROVIDER'];
 if(!['gemini','openai'].includes(provider))throw Error('AI_PROVIDER_REQUIRED');
 const model=provider==='gemini'?env[scope==='coach'?'GEMINI_COACH_MODEL':'GEMINI_FOOD_MODEL']:env[scope==='coach'?'OPENAI_COACH_MODEL':'OPENAI_FOOD_MODEL'];
 const key=provider==='gemini'?(env.GEMINI_API_KEY||env.GOOGLE_API_KEY):env.OPENAI_API_KEY;
 if(!key)throw Error('AI_NOT_CONFIGURED');
 if(!model||!/^[a-zA-Z0-9._-]+$/.test(model))throw Error('AI_MODEL_REQUIRED');
 return {provider,model,key,scope};
}
function gemini(c,parts,schema){return {url:'https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(c.model)+':generateContent',headers:{'x-goog-api-key':c.key,'Content-Type':'application/json'},body:{contents:[{role:'user',parts}],generationConfig:{responseMimeType:'application/json',responseSchema:schema}}}}
function openai(c,content,schema,name){return {url:'https://api.openai.com/v1/responses',headers:{Authorization:'Bearer '+c.key,'Content-Type':'application/json'},body:{model:c.model,input:[{role:'user',content}],text:{format:{type:'json_schema',name,strict:true,schema}}}}}
function prepare(c,image,schema,prompt){const match=/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(image);if(!match)throw Error('IMAGE_REQUIRED');if(c.provider==='gemini')return gemini(c,[{text:prompt},{inlineData:{mimeType:'image/'+(match[1]==='jpg'?'jpeg':match[1]),data:match[2]}}],schema);
 if(c.provider==='openai')return openai(c,[{type:'input_text',text:prompt},{type:'input_image',image_url:image}],schema,'meal_nutrition_estimate');throw Error('AI_PROVIDER_REQUIRED')}
function prepareText(c,input,schema,prompt){const text=prompt+'\n\nINPUT_JSON:\n'+JSON.stringify(input);if(c.provider==='gemini')return gemini(c,[{text}],schema);if(c.provider==='openai')return openai(c,[{type:'input_text',text}],schema,'body_daily_analysis');throw Error('AI_PROVIDER_REQUIRED')}
function parse(provider,body){let text='';if(provider==='gemini'){const candidate=body.candidates?.[0];if(body.promptFeedback?.blockReason||candidate?.finishReason!=='STOP')throw Error('AI_INCOMPLETE');text=(candidate.content?.parts||[]).filter(p=>typeof p.text==='string'&&!p.thought).map(p=>p.text).join('')}else{if(body.status!=='completed'||body.error)throw Error('AI_INCOMPLETE');for(const item of body.output||[])for(const part of item.content||[]){if(part.type==='refusal')throw Error('AI_REFUSED');if(part.type==='output_text')text+=part.text||''}}if(!text)throw Error('AI_EMPTY');const parsed=JSON.parse(text);if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('AI_INVALID_RESULT');return parsed}
module.exports={config,prepare,prepareText,parse};

'use strict';
const crypto=require('node:crypto');

function verifySignature({rawBody,signature,notificationUrl,signatureKey}){
 if(typeof rawBody!=='string'||!rawBody||typeof signature!=='string'||!signature)return false;
 if(typeof notificationUrl!=='string'||!/^https:\/\//i.test(notificationUrl))return false;
 if(typeof signatureKey!=='string'||signatureKey.length<16)return false;
 const expected=crypto.createHmac('sha256',signatureKey).update(notificationUrl+rawBody,'utf8').digest();
 let actual;try{actual=Buffer.from(signature,'base64')}catch{return false}
 return actual.length===expected.length&&crypto.timingSafeEqual(actual,expected);
}
module.exports={verifySignature};

'use strict';
function cleanName(value,fallback){const x=String(value||fallback);if(!/^[a-z][a-z0-9_]{1,62}$/.test(x))throw Error('STORE_TABLE_INVALID');return x}
function httpsBase(value){const u=new URL(String(value||''));if(u.protocol!=='https:')throw Error('STORE_URL_INVALID');return u.origin}
async function jsonRequest(fetchImpl,url,options){
 const r=await fetchImpl(url,{...options,redirect:'error',signal:AbortSignal.timeout(10000)}),text=await r.text();let body=null;try{body=text?JSON.parse(text):null}catch{body=text}
 if(!r.ok){const e=Error('STORE_REQUEST_FAILED');e.status=r.status;throw e}return body;
}
function createRepository(config,fetchImpl=fetch){
 const base=httpsBase(config.url),publicKey=String(config.publishableKey||''),serviceKey=String(config.serviceRoleKey||'');
 if(!publicKey)throw Error('STORE_PUBLIC_KEY_REQUIRED');if(!serviceKey)throw Error('STORE_SERVICE_KEY_REQUIRED');
 const profiles=cleanName(config.profilesTable,'profiles'),memberships=cleanName(config.membershipsTable,'body_memberships'),entitlements=cleanName(config.entitlementsTable,'body_entitlements'),pending=cleanName(config.pendingTable,'body_pending_purchases'),subscriptions=cleanName(config.subscriptionsTable,'body_square_subscriptions'),rpc=cleanName(config.entitlementRpc,'apply_body_entitlement_event');
 const serviceHeaders={apikey:serviceKey,Authorization:'Bearer '+serviceKey,Accept:'application/json'};
 const rest=(path,options={})=>jsonRequest(fetchImpl,base+'/rest/v1/'+path,{...options,headers:{...serviceHeaders,...options.headers}});
 return{
  async verifyUser(accessToken){if(!accessToken)throw Error('AUTH_REQUIRED');const user=await jsonRequest(fetchImpl,base+'/auth/v1/user',{method:'GET',headers:{apikey:publicKey,Authorization:'Bearer '+accessToken,Accept:'application/json'}});if(!user?.id)throw Error('AUTH_INVALID');return{id:String(user.id)}},
  async getProfile(accountId){const rows=await rest(`${profiles}?id=eq.${encodeURIComponent(accountId)}&select=id,role&limit=1`);return Array.isArray(rows)?rows[0]||null:null},
  async getMembership(accountId){const rows=await rest(`${memberships}?account_id=eq.${encodeURIComponent(accountId)}&select=account_id,status,updated_at&limit=1`);return Array.isArray(rows)?rows[0]||null:null},
  async getEntitlement(accountId,productId){const rows=await rest(`${entitlements}?account_id=eq.${encodeURIComponent(accountId)}&product_id=eq.${encodeURIComponent(productId)}&select=account_id,product_id,status,valid_until,billing_status,subscription_id,updated_at&limit=1`);return Array.isArray(rows)?rows[0]||null:null},
  async getPendingByPaymentId(paymentId){const rows=await rest(`${pending}?payment_id=eq.${encodeURIComponent(paymentId)}&select=account_id,product_id,payment_id,amount,currency,status&limit=1`);const x=Array.isArray(rows)?rows[0]:null;return x?{accountId:x.account_id,productId:x.product_id,paymentId:x.payment_id,amount:Number(x.amount),currency:x.currency,status:x.status}:null},
  async getSubscriptionBindingBySubscriptionId(subscriptionId){const rows=await rest(`${subscriptions}?subscription_id=eq.${encodeURIComponent(subscriptionId)}&select=account_id,product_id,subscription_id,plan_variation_id,customer_id,status&limit=1`);const x=Array.isArray(rows)?rows[0]:null;return x?{accountId:x.account_id,productId:x.product_id,subscriptionId:x.subscription_id,planVariationId:x.plan_variation_id,customerId:x.customer_id||'',status:x.status}:null},
  async applyAtomic(event,mutation){const body=await rest(`rpc/${rpc}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({p_event_id:event.event_id,p_event_type:event.type,p_action:mutation.action,p_account_id:mutation.accountId,p_product_id:mutation.productId,p_payment_id:mutation.paymentId||null,p_refund_id:mutation.refundId||null,p_subscription_id:mutation.subscriptionId||null,p_invoice_id:mutation.invoiceId||null,p_valid_until:mutation.validUntil||null,p_billing_status:mutation.billingStatus||null,p_preserve_access:mutation.preserveExistingAccess===true})});const row=Array.isArray(body)?body[0]:body;if(!row||!['applied','duplicate'].includes(row.status))throw Error('ATOMIC_STORE_RESPONSE_INVALID');return{status:row.status,eventId:event.event_id,entitlement:row.entitlement||null}}
 };
}
function fromEnv(env,fetchImpl=fetch){return createRepository({url:env.BODY_SUPABASE_URL,publishableKey:env.BODY_SUPABASE_PUBLISHABLE_KEY,serviceRoleKey:env.BODY_SUPABASE_SERVICE_ROLE_KEY,profilesTable:env.BODY_PROFILES_TABLE,membershipsTable:env.BODY_MEMBERSHIPS_TABLE,entitlementsTable:env.BODY_ENTITLEMENTS_TABLE,pendingTable:env.BODY_PENDING_PURCHASES_TABLE,subscriptionsTable:env.BODY_SQUARE_SUBSCRIPTIONS_TABLE,entitlementRpc:env.BODY_ENTITLEMENT_RPC},fetchImpl)}
module.exports={createRepository,fromEnv};

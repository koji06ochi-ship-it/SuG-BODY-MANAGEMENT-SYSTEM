'use strict';

const { PLAN } = require('./body-square-monthly-plan.cjs');
const EVENT_TYPES = new Set([
  'subscription.created', 'subscription.updated',
  'invoice.payment_made', 'invoice.scheduled_charge_failed', 'invoice.canceled', 'invoice.refunded'
]);

function dateValue(value, name) {
  const date = String(value || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error(name + '_REQUIRED');
  return date;
}

function validateBinding(binding, subscription) {
  if (!binding?.accountId || binding.productId !== PLAN.productId || !binding.subscriptionId || !binding.planVariationId) throw new Error('SUBSCRIPTION_BINDING_REQUIRED');
  if (subscription?.id !== binding.subscriptionId) throw new Error('SUBSCRIPTION_ID_MISMATCH');
  if (subscription?.plan_variation_id !== binding.planVariationId && subscription?.planVariationId !== binding.planVariationId) throw new Error('PLAN_VARIATION_MISMATCH');
  const customerId = subscription?.customer_id || subscription?.customerId;
  if (binding.customerId && customerId !== binding.customerId) throw new Error('CUSTOMER_ID_MISMATCH');
}

function invoiceMoney(invoice) {
  const requests = Array.isArray(invoice?.payment_requests) ? invoice.payment_requests : [];
  const computed = requests.reduce((sum, row) => sum + Number(row?.computed_amount_money?.amount || 0), 0);
  const completed = requests.reduce((sum, row) => sum + Number(row?.total_completed_amount_money?.amount || 0), 0);
  const currencies = new Set(requests.flatMap((row) => [row?.computed_amount_money?.currency, row?.total_completed_amount_money?.currency]).filter(Boolean));
  return { computed, completed, currencies };
}

function baseMutation(event, binding, subscription) {
  return {
    eventId: event.event_id,
    accountId: binding.accountId,
    productId: PLAN.productId,
    subscriptionId: binding.subscriptionId,
    planVariationId: binding.planVariationId,
    // paid_until_date is the paid-access boundary. charged_through_date is kept
    // as a compatibility fallback for older Square responses.
    validUntil: subscription?.paid_until_date || subscription?.paidUntilDate || subscription?.charged_through_date || subscription?.chargedThroughDate || null,
    requireAtomicDeduplication: true,
    lifecycle: 'subscription'
  };
}

function planLifecycleMutation({ event, subscription, invoice = null, binding }) {
  if (!event?.event_id || !EVENT_TYPES.has(event.type)) throw new Error('SUBSCRIPTION_EVENT_REQUIRED');
  validateBinding(binding, subscription);
  const base = baseMutation(event, binding, subscription);
  const subscriptionStatus = String(subscription.status || '');

  if (event.type === 'subscription.created') return null;
  if (event.type === 'subscription.updated') {
    if (['PENDING', 'ACTIVE'].includes(subscriptionStatus)) {
      const canceledDate = subscription.canceled_date || subscription.canceledDate || null;
      if (!canceledDate) return null;
      const validUntil = base.validUntil || canceledDate;
      return { ...base, action: 'schedule_expiry', validUntil, billingStatus: 'cancel_scheduled' };
    }
    if (['CANCELED', 'DEACTIVATED', 'PAUSED', 'COMPLETED'].includes(subscriptionStatus)) {
      const validUntil = base.validUntil || subscription.canceled_date || subscription.completed_date || null;
      return { ...base, action: validUntil ? 'schedule_expiry' : 'revoke', validUntil, billingStatus: subscriptionStatus.toLowerCase() };
    }
    throw new Error('SUBSCRIPTION_STATUS_UNSUPPORTED');
  }

  if (!invoice?.id) throw new Error('CANONICAL_INVOICE_REQUIRED');
  if (String(invoice.subscription_id || invoice.subscriptionId || '') !== binding.subscriptionId) throw new Error('INVOICE_SUBSCRIPTION_MISMATCH');
  const invoiceId = String(invoice.id);

  if (event.type === 'invoice.payment_made') {
    if (invoice.status !== 'PAID') throw new Error('INVOICE_NOT_PAID');
    if (subscriptionStatus !== 'ACTIVE') throw new Error('SUBSCRIPTION_NOT_ACTIVE');
    const money = invoiceMoney(invoice);
    if (money.computed !== PLAN.amount || money.completed !== PLAN.amount || money.currencies.size !== 1 || !money.currencies.has(PLAN.currency)) throw new Error('MONTHLY_AMOUNT_OR_CURRENCY_MISMATCH');
    return { ...base, action: 'grant_period', invoiceId, validUntil: dateValue(base.validUntil, 'CHARGED_THROUGH_DATE'), billingStatus: 'paid' };
  }

  if (event.type === 'invoice.scheduled_charge_failed' || event.type === 'invoice.canceled') {
    return { ...base, action: 'payment_failed', invoiceId, billingStatus: event.type === 'invoice.canceled' ? 'invoice_canceled' : 'past_due', preserveExistingAccess: true };
  }

  if (event.type === 'invoice.refunded') {
    if (invoice.status === 'REFUNDED') return { ...base, action: 'revoke', invoiceId, billingStatus: 'refunded' };
    return { ...base, action: 'manual_review', invoiceId, billingStatus: 'partial_refund', preserveExistingAccess: true };
  }

  throw new Error('SUBSCRIPTION_EVENT_UNSUPPORTED');
}

module.exports = { EVENT_TYPES, invoiceMoney, planLifecycleMutation };

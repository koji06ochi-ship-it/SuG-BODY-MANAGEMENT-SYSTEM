'use strict';
const {REQUIRED_WEBHOOK_EVENTS}=require('./body-square-monthly-plan.cjs');
function maskId(value){const s=String(value||'');return s?('***'+s.slice(-4)):'未取得'}
function safeError(error){return String(error?.message||'SQUARE_READ_FAILED').replace(/Bearer\s+\S+/gi,'Bearer <redacted>').slice(0,120)}
async function inspect({client,expectedMerchantId='',expectedWebhookUrl='',requiredEvents=REQUIRED_WEBHOOK_EVENTS}){
 if(!client)throw Error('SQUARE_CLIENT_REQUIRED');
 const [merchantResult,catalogResult,webhookResult]=await Promise.allSettled([client.listMerchants(),client.listCatalogItems({maxPages:10}),client.listWebhookSubscriptions()]);
 const merchants=merchantResult.status==='fulfilled'?merchantResult.value:[],catalog=catalogResult.status==='fulfilled'?catalogResult.value:{items:[],truncated:false,pages:0},hooks=webhookResult.status==='fulfilled'?webhookResult.value:[];
 const merchant=merchants[0]||null,bodyItems=catalog.items.filter(x=>/\bbody\b|Ｓ\.ｕ\.Ｇ\s*ＢＯＤＹ|s\.u\.g\s*body/i.test(x.name));
 const matchingHooks=hooks.filter(x=>expectedWebhookUrl&&x.notificationUrl===expectedWebhookUrl),activeHooks=hooks.filter(x=>x.enabled);
 const eventTypes=new Set(activeHooks.flatMap(x=>x.eventTypes));
 return{
  environment:String(client.environment||'unknown'),
  merchant:{found:Boolean(merchant),count:merchants.length,idMasked:maskId(merchant?.id),matchesConfiguredId:Boolean(merchant&&expectedMerchantId&&merchant.id===expectedMerchantId),status:merchant?.status||'',country:merchant?.country||'',currency:merchant?.currency||''},
  catalog:{itemCount:catalog.items.length,bodyCandidateCount:bodyItems.length,bodyCandidateNames:bodyItems.slice(0,20).map(x=>x.name),pages:catalog.pages,truncated:catalog.truncated},
  webhooks:{count:hooks.length,enabledCount:activeHooks.length,configuredUrlMatchCount:matchingHooks.length,requiredEvents:Object.fromEntries(requiredEvents.map(x=>[x,eventTypes.has(x)]))},
  errors:{merchant:merchantResult.status==='rejected'?safeError(merchantResult.reason):null,catalog:catalogResult.status==='rejected'?safeError(catalogResult.reason):null,webhooks:webhookResult.status==='rejected'?safeError(webhookResult.reason):null}
 };
}
module.exports={maskId,inspect};

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { catalogDraft, validateCatalog } = require('./body-square-monthly-plan.cjs');

const SANDBOX_BASE = 'https://connect.squareupsandbox.com';
const ITEM_NAME = 'S.u.G BODY';
const ITEM_VARIATION_NAME = '一般向け月額';
const PLAN_NAME = 'S.u.G BODY 一般向け';
const VARIATION_NAME = '月額1,480円（税込）';
const DEFAULT_OUTPUT = path.resolve(__dirname, '../apps/body/daily-preview/square-sandbox-monthly-plan-result.json');

function validateApiVersion(value) {
  const version = String(value || '2026-09-16');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(version)) throw new Error('SQUARE_API_VERSION_INVALID');
  return version;
}

function maskId(value) {
  const id = String(value || '');
  return id ? `***${id.slice(-4)}` : '';
}

function safeCodes(body) {
  return Array.isArray(body?.errors)
    ? body.errors.map((entry) => String(entry?.code || '')).filter((code) => /^[A-Z0-9_]+$/.test(code)).slice(0, 5)
    : [];
}

function sanitizeResult(result, token) {
  const serialized = JSON.stringify(result);
  if (token && serialized.includes(token)) throw new Error('SECRET_OUTPUT_BLOCKED');
  if (serialized.includes('connect.squareup.com')) throw new Error('PRODUCTION_ENDPOINT_OUTPUT_BLOCKED');
  return result;
}

function safeWrite(writeResult, result, token) {
  sanitizeResult(result, token);
  writeResult(result);
}

function createRequester({ accessToken, apiVersion, fetchImpl }) {
  async function request(method, requestPath, body) {
    let response;
    try {
      response = await fetchImpl(`${SANDBOX_BASE}${requestPath}`, {
        method,
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Square-Version': apiVersion,
          Accept: 'application/json',
          ...(body ? { 'Content-Type': 'application/json' } : {})
        },
        ...(body ? { body: JSON.stringify(body) } : {}),
        redirect: 'error',
        signal: AbortSignal.timeout(15000)
      });
    } catch {
      const error = new Error('SQUARE_NETWORK_FAILED');
      error.isNetwork = true;
      throw error;
    }

    let parsed = null;
    try {
      const text = await response.text();
      parsed = text ? JSON.parse(text) : {};
    } catch {
      parsed = null;
    }
    if (!response.ok) {
      const codes = safeCodes(parsed);
      const error = new Error(`SQUARE_HTTP_${response.status || 0}${codes.length ? `_CODES_${codes.join(',')}` : ''}`);
      error.httpStatus = Number(response.status || 0);
      error.squareCodes = codes;
      throw error;
    }
    if (!parsed || typeof parsed !== 'object') throw new Error('SQUARE_INVALID_JSON');
    return parsed;
  }
  return { get: (requestPath) => request('GET', requestPath), post: (requestPath, body) => request('POST', requestPath, body) };
}

function expandCatalogObjects(objects) {
  const expanded = [];
  for (const object of Array.isArray(objects) ? objects : []) {
    expanded.push(object);
    if (object?.type === 'ITEM') {
      const nested = object.item_data?.variations;
      if (Array.isArray(nested)) expanded.push(...nested);
    }
    if (object?.type === 'SUBSCRIPTION_PLAN') {
      const nested = object.subscription_plan_data?.subscription_plan_variations;
      if (Array.isArray(nested)) expanded.push(...nested);
    }
  }
  const seen = new Set();
  return expanded.filter((object) => {
    const key = `${object?.type || ''}:${object?.id || ''}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function listCatalog(requester, maxPages = 10) {
  const objects = [];
  let cursor = '';
  for (let page = 0; page < maxPages; page += 1) {
    const query = new URLSearchParams({ types: 'ITEM,ITEM_VARIATION,SUBSCRIPTION_PLAN,SUBSCRIPTION_PLAN_VARIATION' });
    if (cursor) query.set('cursor', cursor);
    const body = await requester.get(`/v2/catalog/list?${query}`);
    objects.push(...expandCatalogObjects(body.objects));
    cursor = String(body.cursor || '');
    if (!cursor) return objects;
  }
  throw new Error('SQUARE_CATALOG_PAGINATION_LIMIT');
}

function nameOf(object) {
  if (object?.type === 'ITEM') return String(object.item_data?.name || '');
  if (object?.type === 'ITEM_VARIATION') return String(object.item_variation_data?.name || '');
  if (object?.type === 'SUBSCRIPTION_PLAN') return String(object.subscription_plan_data?.name || '');
  if (object?.type === 'SUBSCRIPTION_PLAN_VARIATION') return String(object.subscription_plan_variation_data?.name || '');
  return '';
}

function findNamedObjects(objects) {
  return {
    items: objects.filter((object) => object?.type === 'ITEM' && nameOf(object) === ITEM_NAME),
    itemVariations: objects.filter((object) => object?.type === 'ITEM_VARIATION' && nameOf(object) === ITEM_VARIATION_NAME),
    plans: objects.filter((object) => object?.type === 'SUBSCRIPTION_PLAN' && nameOf(object) === PLAN_NAME),
    variations: objects.filter((object) => object?.type === 'SUBSCRIPTION_PLAN_VARIATION' && nameOf(object) === VARIATION_NAME)
  };
}

function resolveExactSet(objects) {
  const named = findNamedObjects(objects);
  const counts = { item: named.items.length, itemVariation: named.itemVariations.length, plan: named.plans.length, variation: named.variations.length };
  const none = counts.item === 0 && counts.itemVariation === 0 && counts.plan === 0 && counts.variation === 0;
  const exactlyOneEach = counts.item === 1 && counts.itemVariation === 1 && counts.plan === 1 && counts.variation === 1;
  if (!none && !exactlyOneEach) return { state: 'partial_or_duplicate', counts };
  if (none) return { state: 'none', counts };
  const item = named.items[0];
  const itemVariation = named.itemVariations[0];
  const plan = named.plans[0];
  const variation = named.variations[0];
  const validation = validateCatalog(plan, variation, item, itemVariation);
  return { state: validation.ready ? 'valid' : 'invalid', counts, item, itemVariation, plan, variation, validation };
}

function verificationSummary(resolved) {
  const item = resolved.item;
  const itemVariation = resolved.itemVariation;
  const plan = resolved.plan;
  const variation = resolved.variation;
  const phase = variation?.subscription_plan_variation_data?.phases?.[0] || {};
  const money = phase?.pricing?.price_money || phase?.pricing?.price || {};
  return {
    item: { found: Boolean(item), idMasked: maskId(item?.id), name: nameOf(item) },
    itemVariation: {
      found: Boolean(itemVariation),
      idMasked: maskId(itemVariation?.id),
      name: nameOf(itemVariation),
      parentItemIdMasked: maskId(itemVariation?.item_variation_data?.item_id),
      pricingType: String(itemVariation?.item_variation_data?.pricing_type || ''),
      amount: Number(itemVariation?.item_variation_data?.price_money?.amount || 0),
      currency: String(itemVariation?.item_variation_data?.price_money?.currency || '')
    },
    plan: { found: Boolean(plan), idMasked: maskId(plan?.id), name: nameOf(plan) },
    variation: {
      found: Boolean(variation),
      idMasked: maskId(variation?.id),
      name: nameOf(variation),
      amount: Number(money.amount || 0),
      currency: String(money.currency || ''),
      cadence: String(phase.cadence || ''),
      periods: phase.periods ?? null,
      canProrate: variation?.subscription_plan_variation_data?.can_prorate === true
    },
    relationships: {
      itemVariationLinkedItem: itemVariation?.item_variation_data?.item_id === item?.id,
      planEligibleItem: plan?.subscription_plan_data?.eligible_item_ids?.includes(item?.id) === true,
      variationLinkedPlan: variation?.subscription_plan_variation_data?.subscription_plan_id === plan?.id
    },
    tax: {
      finalCatalogPriceJpy: Number(money.amount || 0),
      itemTaxable: item?.item_data?.is_taxable === true,
      itemTaxReferenceCount: Array.isArray(item?.item_data?.tax_ids) ? item.item_data.tax_ids.length : 0,
      additionalTaxObjectCreated: false,
      actualChargeTested: false
    },
    checks: resolved.validation?.checks || {}
  };
}

function baseResult(checkedAt) {
  return {
    checkedAt,
    scope: 'Square Sandbox approved four-object catalog creation',
    environment: 'sandbox',
    productionConnected: false,
    status: 'preflight',
    merchant: { found: false, idMasked: '', status: '', country: '', currency: '' },
    preflight: { duplicateFree: false, counts: { item: 0, itemVariation: 0, plan: 0, variation: 0 } },
    verification: null,
    apiOperations: { getCount: 0, postCount: 0, postEndpoints: [] },
    mutations: {
      approvedCatalogItem: 0,
      approvedCatalogItemVariation: 0,
      approvedSubscriptionPlan: 0,
      approvedSubscriptionPlanVariation: 0,
      webhook: 0,
      customer: 0,
      subscription: 0,
      payment: 0,
      refund: 0,
      database: 0,
      production: 0
    }
  };
}

function safeErrorCode(error, fallback = 'SQUARE_CATALOG_CREATE_FAILED') {
  return String(error?.message || fallback).replace(/[^A-Z0-9_,]/g, '_').slice(0, 180);
}

function stagedObjects(objects) {
  const named = findNamedObjects(objects);
  return {
    named,
    counts: { item: named.items.length, itemVariation: named.itemVariations.length, plan: named.plans.length, variation: named.variations.length }
  };
}

function validateApprovedDraft(draft = catalogDraft()) {
  const item = draft?.item;
  const nested = item?.item_data?.variations;
  const itemVariation = draft?.itemVariation;
  const plan = draft?.plan;
  const variation = draft?.variation;
  const phase = variation?.subscription_plan_variation_data?.phases?.[0];
  const checks = {
    exactlyOneNestedItemVariation: Array.isArray(nested) && nested.length === 1 && nested[0] === itemVariation,
    itemName: item?.type === 'ITEM' && item?.item_data?.name === ITEM_NAME,
    itemNotTaxable: item?.item_data?.is_taxable === false && !item?.item_data?.tax_ids,
    itemVariationName: itemVariation?.type === 'ITEM_VARIATION' && itemVariation?.item_variation_data?.name === ITEM_VARIATION_NAME,
    itemVariationParent: itemVariation?.item_variation_data?.item_id === item?.id,
    itemVariationPrice: itemVariation?.item_variation_data?.pricing_type === 'FIXED_PRICING' && Number(itemVariation?.item_variation_data?.price_money?.amount) === 1480 && itemVariation?.item_variation_data?.price_money?.currency === 'JPY',
    planName: plan?.type === 'SUBSCRIPTION_PLAN' && plan?.subscription_plan_data?.name === PLAN_NAME,
    planEligibleItem: plan?.subscription_plan_data?.eligible_item_ids?.length === 1 && plan.subscription_plan_data.eligible_item_ids[0] === item?.id && plan?.subscription_plan_data?.all_items === false,
    planVariationName: variation?.type === 'SUBSCRIPTION_PLAN_VARIATION' && variation?.subscription_plan_variation_data?.name === VARIATION_NAME,
    planVariationParent: variation?.subscription_plan_variation_data?.subscription_plan_id === plan?.id,
    planVariationPrice: phase?.cadence === 'MONTHLY' && phase?.pricing?.type === 'STATIC' && Number(phase?.pricing?.price_money?.amount) === 1480 && phase?.pricing?.price_money?.currency === 'JPY',
    approvedTypesOnly: [item?.type, itemVariation?.type, plan?.type, variation?.type].join(',') === 'ITEM,ITEM_VARIATION,SUBSCRIPTION_PLAN,SUBSCRIPTION_PLAN_VARIATION'
  };
  return { ready: Object.values(checks).every(Boolean), checks };
}

async function runCatalogCreation({
  accessToken,
  apiVersion = '2026-09-16',
  fetchImpl = fetch,
  expectedMerchantSuffix = '4DBN',
  checkedAt = new Date().toISOString(),
  idempotencyKey = crypto.randomUUID(),
  writeResult = (value) => fs.writeFileSync(DEFAULT_OUTPUT, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
} = {}) {
  const token = String(accessToken || '').trim();
  if (!token) throw new Error('SQUARE_SANDBOX_TOKEN_REQUIRED');
  const version = validateApiVersion(apiVersion);
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(String(idempotencyKey))) throw new Error('IDEMPOTENCY_KEY_INVALID');
  const result = baseResult(checkedAt);
  const requester = createRequester({ accessToken: token, apiVersion: version, fetchImpl });
  const countedGet = async (requestPath) => {
    result.apiOperations.getCount += 1;
    return requester.get(requestPath);
  };
  const listWithCount = async () => {
    const proxy = { get: countedGet };
    return listCatalog(proxy);
  };

  try {
    const merchantBody = await countedGet('/v2/merchants');
    const merchants = Array.isArray(merchantBody.merchant) ? merchantBody.merchant : Array.isArray(merchantBody.merchants) ? merchantBody.merchants : [];
    if (merchants.length !== 1) throw new Error('SANDBOX_MERCHANT_COUNT_MISMATCH');
    const merchant = merchants[0];
    result.merchant = {
      found: true,
      idMasked: maskId(merchant.id),
      status: String(merchant.status || ''),
      country: String(merchant.country || ''),
      currency: String(merchant.currency || '')
    };
    if (!String(merchant.id || '').endsWith(expectedMerchantSuffix)) throw new Error('SANDBOX_MERCHANT_MISMATCH');
    if (result.merchant.status !== 'ACTIVE' || result.merchant.country !== 'JP' || result.merchant.currency !== 'JPY') throw new Error('SANDBOX_MERCHANT_NOT_READY');

    const before = resolveExactSet(await listWithCount());
    result.preflight.counts = before.counts;
    if (before.state === 'valid') {
      result.preflight.duplicateFree = true;
      result.status = 'existing_verified';
      result.verification = verificationSummary(before);
      safeWrite(writeResult, result, token);
      return result;
    }
    if (before.state !== 'none') throw new Error('CATALOG_DUPLICATE_PARTIAL_OR_INVALID');
    result.preflight.duplicateFree = true;

    const draft = catalogDraft();
    const draftValidation = validateApprovedDraft(draft);
    const approvedObjects = [draft.item, draft.itemVariation, draft.plan, draft.variation];
    if (!draftValidation.ready || approvedObjects.length !== 4) {
      throw new Error('APPROVED_OBJECT_SCOPE_INVALID');
    }
    result.preflight.approvedObjectCount = 4;
    result.preflight.approvedDraftChecks = draftValidation.checks;

    async function upsertStage(stage, object, keySuffix, confirm) {
      result.apiOperations.postCount += 1;
      result.apiOperations.postEndpoints.push('/v2/catalog/object');
      let postError = null;
      try {
        await requester.post('/v2/catalog/object', {
          idempotency_key: `${idempotencyKey}-${keySuffix}`,
          object
        });
      } catch (error) {
        postError = error;
      }

      let afterObjects;
      try {
        afterObjects = await listWithCount();
      } catch (confirmError) {
        result.status = 'unknown_after_post';
        result.errorCode = postError ? `${safeErrorCode(postError)}_GET_CONFIRMATION_FAILED` : 'POST_SUCCEEDED_GET_CONFIRMATION_FAILED';
        result.failedStage = stage;
        safeWrite(writeResult, result, token);
        throw confirmError;
      }
      const staged = stagedObjects(afterObjects);
      result.preflight.afterCounts = staged.counts;
      const confirmed = confirm(staged.named);
      if (!confirmed) {
        result.status = postError?.isNetwork ? 'unknown_after_post' : 'rejected';
        result.errorCode = postError ? safeErrorCode(postError) : `${stage.toUpperCase()}_GET_VERIFICATION_FAILED`;
        result.failedStage = stage;
        safeWrite(writeResult, result, token);
        const failure = new Error(result.errorCode);
        failure.stageHandled = true;
        throw failure;
      }
      return staged.named;
    }

    const afterItem = await upsertStage('item', draft.item, 'item', (named) => (
      named.items.length === 1 && named.itemVariations.length === 1 && named.plans.length === 0 && named.variations.length === 0 &&
      validateCatalog(null, null, named.items[0], named.itemVariations[0]).checks.itemVariationType &&
      named.itemVariations[0].item_variation_data?.item_id === named.items[0].id &&
      named.itemVariations[0].item_variation_data?.pricing_type === 'FIXED_PRICING' &&
      Number(named.itemVariations[0].item_variation_data?.price_money?.amount) === 1480 &&
      named.itemVariations[0].item_variation_data?.price_money?.currency === 'JPY' &&
      named.items[0].item_data?.is_taxable === false &&
      (!Array.isArray(named.items[0].item_data?.tax_ids) || named.items[0].item_data.tax_ids.length === 0)
    ));
    result.mutations.approvedCatalogItem = 1;
    result.mutations.approvedCatalogItemVariation = 1;
    const item = afterItem.items[0];

    const planObject = {
      ...draft.plan,
      subscription_plan_data: {
        ...draft.plan.subscription_plan_data,
        eligible_item_ids: [item.id]
      }
    };
    const afterPlan = await upsertStage('plan', planObject, 'plan', (named) => (
      named.items.length === 1 && named.itemVariations.length === 1 && named.plans.length === 1 && named.variations.length === 0 &&
      named.plans[0].subscription_plan_data?.eligible_item_ids?.length === 1 &&
      named.plans[0].subscription_plan_data.eligible_item_ids[0] === named.items[0].id &&
      named.plans[0].subscription_plan_data?.all_items === false
    ));
    result.mutations.approvedSubscriptionPlan = 1;
    const plan = afterPlan.plans[0];

    const variationObject = {
      ...draft.variation,
      subscription_plan_variation_data: {
        ...draft.variation.subscription_plan_variation_data,
        subscription_plan_id: plan.id
      }
    };
    const afterVariation = await upsertStage('variation', variationObject, 'variation', (named) => {
      if (named.items.length !== 1 || named.itemVariations.length !== 1 || named.plans.length !== 1 || named.variations.length !== 1) return false;
      return validateCatalog(named.plans[0], named.variations[0], named.items[0], named.itemVariations[0]).ready;
    });
    result.mutations.approvedSubscriptionPlanVariation = 1;
    const after = resolveExactSet([
      afterVariation.items[0],
      afterVariation.itemVariations[0],
      afterVariation.plans[0],
      afterVariation.variations[0]
    ]);

    result.status = 'created_verified';
    result.verification = verificationSummary(after);
    safeWrite(writeResult, result, token);
    return result;
  } catch (error) {
    if (!['created_verified', 'existing_verified', 'unknown_after_post', 'created_but_verification_failed'].includes(result.status)) {
      result.status = 'rejected';
      result.errorCode = safeErrorCode(error);
      if (result.apiOperations.postCount === 0) safeWrite(writeResult, result, token);
      else if (!error?.isNetwork && !error?.stageHandled) safeWrite(writeResult, result, token);
    }
    error.safeResult = result;
    throw error;
  }
}

module.exports = {
  DEFAULT_OUTPUT,
  ITEM_NAME,
  ITEM_VARIATION_NAME,
  PLAN_NAME,
  SANDBOX_BASE,
  VARIATION_NAME,
  expandCatalogObjects,
  findNamedObjects,
  listCatalog,
  resolveExactSet,
  runCatalogCreation,
  validateApprovedDraft
};

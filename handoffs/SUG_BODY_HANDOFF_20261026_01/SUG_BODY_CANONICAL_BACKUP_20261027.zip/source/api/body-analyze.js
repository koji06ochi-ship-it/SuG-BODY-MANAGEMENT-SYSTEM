'use strict';
const provider=require('./food-provider.cjs'),auth=require('./ai-auth.cjs'),core=require('./body-ai-core.cjs');
const allowedOrigin=/^https:\/\/(koji06ochi-ship-it\.github\.io|[^/]+\.vercel\.app)$/i;
function cors(req,res){const origin=String(req.headers?.origin||'');if(allowedOrigin.test(origin))res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');res.setHeader('Access-Control-Allow-Methods','POST,OPTIONS')}
const nullableNumber={anyOf:[{type:'number'},{type:'null'}]};
const schema={type:'object',additionalProperties:false,properties:{summary:{type:'string'},observations:{type:'array',items:{type:'object',additionalProperties:false,properties:{text:{type:'string'},confidence:nullableNumber,evidenceFields:{type:'array',items:{type:'string'}}},required:['text','confidence','evidenceFields']}},suggestions:{type:'array',items:{type:'object',additionalProperties:false,properties:{title:{type:'string'},reason:{type:'string'},action:{type:'string'},mealOptionIds:{type:'array',items:{type:'string'}},requiresConfirmation:{type:'boolean'}},required:['title','reason','action','mealOptionIds','requiresConfirmation']}},missingData:{type:'array',items:{type:'string'}}},required:['summary','observations','suggestions','missingData']};
module.exports=async function handler(req,res){
 cors(req,res);
 if(req.method==='OPTIONS')return res.status(204).end();
 if(req.method!=='POST')return res.status(405).json({error:'METHOD_NOT_ALLOWED'});
 if(process.env.BODY_COACH_AI_ENABLED!=='true')return res.status(503).json({error:'AI_DISABLED'});
 if(process.env.BODY_COACH_AI_COST_APPROVED!=='true')return res.status(503).json({error:'AI_COST_NOT_APPROVED'});
 try{auth.authorize(req,process.env,'body:coach')}catch(e){return res.status(e.message==='AI_AUTH_NOT_CONFIGURED'?503:401).json({error:e.message})}
 let configuration;try{configuration=provider.config(process.env,'coach')}catch(e){return res.status(503).json({error:e.message})}
 let input;try{input=core.sanitize(req.body)}catch(e){return res.status(400).json({error:e.message})}
 try{
  const prompt='Analyze only the supplied BODY daily summary. Return concise Japanese observations and improvement candidates for the member goal. Every observation must cite input metric keys in evidenceFields. If suggesting a meal, choose only IDs supplied in mealOptions and return them in mealOptionIds; never invent a food or quantity. Treat missing data as missing, do not invent values, do not diagnose disease or state a certain cause. Ask for confirmation where uncertainty matters.';
  const request=provider.prepareText(configuration,input,schema,prompt),upstream=await fetch(request.url,{method:'POST',headers:request.headers,body:JSON.stringify(request.body),signal:AbortSignal.timeout(18000),redirect:'error'});
  if(!upstream.ok)return res.status(upstream.status===429?429:502).json({error:upstream.status===429?'AI_QUOTA_LIMIT':'AI_UPSTREAM'});
  const output=core.normalize(provider.parse(configuration.provider,await upstream.json()),input);
  return res.status(200).json({...output,provider:configuration.provider,model:configuration.model,analysisKind:'external-ai-daily-summary',dataSent:['deidentifiedDailyMetrics','confirmedMealSummary','trainingSummary']});
 }catch(_){return res.status(502).json({error:'AI_FAILED'})}
};

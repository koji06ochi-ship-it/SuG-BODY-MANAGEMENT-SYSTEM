'use strict';
const allowedMetrics=['steps','sleepHours','restingEnergyKcal','activeEnergyKcal','totalEnergyKcal','intakeKcal','proteinG','fatG','carbsG','targetKcal','targetProteinG','targetFatG','targetCarbsG','weightKg','weightChangeKg','recoveryScore','stressScore','trainingLoad'];
function number(value,min,max){return typeof value==='number'&&Number.isFinite(value)&&value>=min&&value<=max?value:null}
function sanitize(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('AI_INPUT_REQUIRED');
 const metrics={};for(const key of allowedMetrics){const row=input.metrics?.[key];if(!row||typeof row!=='object')continue;const value=number(row.value,-100000,100000);if(value===null)continue;metrics[key]={value,source:['healthkit_native','manual','calculated','food_log'].includes(row.source)?row.source:'unknown',observedAt:String(row.observedAt||'').slice(0,40)}}
 const missing=Array.isArray(input.missing)?input.missing.filter(x=>allowedMetrics.includes(x)).slice(0,20):[];
 const mealOptions=Array.isArray(input.mealOptions)?input.mealOptions.slice(0,30).map(x=>({id:String(x.id||'').slice(0,80),goal:String(x.goal||'').slice(0,30),slot:String(x.slot||'').slice(0,20),kcal:number(x.kcal,0,10000),p:number(x.p,0,1000),f:number(x.f,0,1000),c:number(x.c,0,2000)})).filter(x=>x.id):[];
 return{day:/^\d{4}-\d{2}-\d{2}$/.test(input.day)?input.day:'',goal:['loss','maintain','gain','performance','wellbeing'].includes(input.goal)?input.goal:'wellbeing',metrics,missing,mealSummary:Array.isArray(input.mealSummary)?input.mealSummary.slice(0,12).map(x=>({slot:String(x.slot||'').slice(0,20),kcal:number(x.kcal,0,10000),p:number(x.p,0,1000),f:number(x.f,0,1000),c:number(x.c,0,2000),confirmed:x.confirmed===true})):[],trainingSummary:Array.isArray(input.trainingSummary)?input.trainingSummary.slice(0,12).map(x=>({type:String(x.type||'').slice(0,60),load:number(x.load,0,100000),completed:x.completed===true})):[],mealOptions};
}
function normalize(output,input){
 if(!output||typeof output!=='object'||Array.isArray(output))throw Error('AI_INVALID_RESULT');
 const evidence=new Set(Object.keys(input.metrics));
 const observations=(Array.isArray(output.observations)?output.observations:[]).slice(0,8).map(x=>({text:String(x?.text||'').slice(0,240),confidence:number(x?.confidence,0,1),evidenceFields:(Array.isArray(x?.evidenceFields)?x.evidenceFields:[]).filter(k=>evidence.has(k)).slice(0,8)})).filter(x=>x.text&&x.evidenceFields.length);
 const optionIds=new Set(input.mealOptions.map(x=>x.id)),suggestions=(Array.isArray(output.suggestions)?output.suggestions:[]).slice(0,8).map(x=>({title:String(x?.title||'').slice(0,80),reason:String(x?.reason||'').slice(0,240),action:String(x?.action||'').slice(0,240),mealOptionIds:(Array.isArray(x?.mealOptionIds)?x.mealOptionIds:[]).map(String).filter(id=>optionIds.has(id)).slice(0,3),requiresConfirmation:x?.requiresConfirmation!==false})).filter(x=>x.title&&x.action);
 return{summary:String(output.summary||'').slice(0,400),observations,suggestions,missingData:(Array.isArray(output.missingData)?output.missingData:[]).map(String).slice(0,20),safetyNote:'記録に基づく候補です。診断や原因の断定ではありません。'};
}
module.exports={allowedMetrics,sanitize,normalize};

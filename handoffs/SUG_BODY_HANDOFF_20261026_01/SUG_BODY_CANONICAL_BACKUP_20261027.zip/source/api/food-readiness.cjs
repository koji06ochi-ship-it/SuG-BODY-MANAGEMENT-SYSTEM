'use strict';
// Local diagnostics only: no network, file writes, or credential values in output.
const adapter = require('./food-provider.cjs');
function inspect(env) {
  const providers = ['gemini', 'openai'].map(provider => {
    let reason = null;
    try { adapter.config({...env, BODY_FOOD_AI_PROVIDER: provider}); }
    catch (error) { reason = error.message; }
    return {provider, configured: reason === null, reason};
  });
  const selected = ['gemini', 'openai'].includes(env.BODY_FOOD_AI_PROVIDER)
    ? env.BODY_FOOD_AI_PROVIDER : null;
  const blockers = [];
  if (!selected) blockers.push('AI_PROVIDER_REQUIRED');
  else if (!providers.find(p => p.provider === selected).configured)
    blockers.push(providers.find(p => p.provider === selected).reason);
  if (env.BODY_FOOD_AI_ENABLED !== 'true') blockers.push('AI_DISABLED');
  if (env.BODY_FOOD_AI_COST_APPROVED !== 'true') blockers.push('AI_COST_NOT_APPROVED');
  if (String(env.BODY_AI_SESSION_SECRET || '').length < 32) blockers.push('AI_AUTH_NOT_CONFIGURED');
  return {selected, providers, serverConfigurationReady: blockers.length === 0,
    blockers, networkRequests: 0, liveAnalysisVerified: false,
    deploymentReady: false,
    remaining: ['client activation', 'member token issuer and rate limiting',
      'approved cost conditions', 'real photo verification']};
}
module.exports = {inspect};
if (require.main === module) process.stdout.write(JSON.stringify(inspect(process.env), null, 2) + '\n');

'use strict';
const policy=require('./body-access-policy.cjs');
function dateKey(now=new Date(),timeZone='Asia/Tokyo'){const parts=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);const get=x=>parts.find(p=>p.type===x)?.value;return `${get('year')}-${get('month')}-${get('day')}`}
function activeEntitlement(entitlement,today){return entitlement?.status==='active'&&/^\d{4}-\d{2}-\d{2}$/.test(String(entitlement.valid_until||''))&&String(entitlement.valid_until)>=today}
async function accessStatus({accessToken,repository,productId='body_general',now=new Date(),timeZone='Asia/Tokyo'}){
 const user=await repository.verifyUser(accessToken),profile=await repository.getProfile(user.id);if(!profile||String(profile.id)!==user.id)throw Error('PROFILE_REQUIRED');
 const role=String(profile.role||'');let membershipStatus='inactive',entitlementStatus='inactive',entitlementValidUntil=null;if(role==='member'){const m=await repository.getMembership(user.id);membershipStatus=m?.status==='active'?'active':'inactive'}if(role==='body_customer'){const e=await repository.getEntitlement(user.id,productId);entitlementValidUntil=e?.valid_until||null;entitlementStatus=activeEntitlement(e,dateKey(now,timeZone))?'active':'inactive'}
 const input={authenticated:true,serverVerified:true,accountId:user.id,role,membershipStatus,entitlementStatus,staffStatus:['trainer','admin'].includes(role)?'active':'inactive'};
 const decision=policy.session(input);return{allowed:decision.allowed,reason:decision.reason,permissions:decision.permissions,authenticated:true,serverVerified:true,role:decision.allowed?role:null,entitlementValidUntil};
}
module.exports={dateKey,activeEntitlement,accessStatus};

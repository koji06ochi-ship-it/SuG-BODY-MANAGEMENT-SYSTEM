import repoCore from './body-supabase-repository.cjs';
import squareCore from './body-square-client.cjs';
import service from './body-square-webhook-service.cjs';

const reply=(body,status)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(request){
 if(process.env.BODY_SQUARE_WEBHOOK_ENABLED!=='true')return reply({error:'SQUARE_WEBHOOK_DISABLED'},503);
 try{
  const rawBody=await request.text();if(rawBody.length>1_000_000)throw Error('BODY_TOO_LARGE');
  const repository=repoCore.fromEnv(process.env),square=squareCore.createClient({accessToken:process.env.SQUARE_ACCESS_TOKEN,environment:process.env.SQUARE_ENVIRONMENT,apiVersion:process.env.SQUARE_API_VERSION});
  const result=await service.processWebhook({rawBody,signature:String(request.headers.get('x-square-hmacsha256-signature')||''),notificationUrl:process.env.SQUARE_WEBHOOK_NOTIFICATION_URL,signatureKey:process.env.SQUARE_WEBHOOK_SIGNATURE_KEY,square,repository});
  return reply(result,200);
 }catch(e){const invalid=/signature|webhook JSON|unsupported|OBJECT_ID|BODY_TOO_LARGE/i.test(e.message);return reply({error:e.message},invalid?400:503)}
}
export function GET(){return reply({error:'METHOD_NOT_ALLOWED'},405)}
